﻿namespace Library_Reserved_System_Cust
{
    partial class Verify
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Verify));
            txtVerify = new TextBox();
            btnVerify = new Button();
            pictureLogo = new PictureBox();
            panZoneVerify = new Panel();
            lblVaildTime = new Label();
            lblTimer = new Label();
            btnAgainSend = new Button();
            lblNotice = new Label();
            panTxtVerify = new Panel();
            lblVerify = new Label();
            lblTitle = new Label();
            timer1 = new System.Windows.Forms.Timer(components);
            ((System.ComponentModel.ISupportInitialize)pictureLogo).BeginInit();
            panZoneVerify.SuspendLayout();
            panTxtVerify.SuspendLayout();
            SuspendLayout();
            // 
            // txtVerify
            // 
            txtVerify.BorderStyle = BorderStyle.FixedSingle;
            txtVerify.Font = new Font("標楷體", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtVerify.Location = new Point(3, 3);
            txtVerify.Multiline = true;
            txtVerify.Name = "txtVerify";
            txtVerify.PlaceholderText = "XXXX";
            txtVerify.Size = new Size(282, 28);
            txtVerify.TabIndex = 1;
            txtVerify.Click += txtVerify_Click;
            txtVerify.Leave += txtVerify_Leave;
            // 
            // btnVerify
            // 
            btnVerify.BackColor = Color.FromArgb(0, 192, 0);
            btnVerify.FlatAppearance.BorderColor = Color.FromArgb(0, 192, 0);
            btnVerify.FlatAppearance.BorderSize = 3;
            btnVerify.FlatAppearance.MouseDownBackColor = Color.FromArgb(0, 152, 0);
            btnVerify.FlatAppearance.MouseOverBackColor = Color.FromArgb(0, 172, 0);
            btnVerify.FlatStyle = FlatStyle.Flat;
            btnVerify.Font = new Font("標楷體", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnVerify.ForeColor = Color.White;
            btnVerify.Location = new Point(13, 229);
            btnVerify.Name = "btnVerify";
            btnVerify.Size = new Size(288, 38);
            btnVerify.TabIndex = 2;
            btnVerify.Text = "驗證";
            btnVerify.UseVisualStyleBackColor = false;
            btnVerify.Click += btnVerify_Click;
            // 
            // pictureLogo
            // 
            pictureLogo.BackColor = Color.AntiqueWhite;
            pictureLogo.Image = Properties.Resources.mustguy;
            pictureLogo.Location = new Point(217, 88);
            pictureLogo.Name = "pictureLogo";
            pictureLogo.Size = new Size(33, 34);
            pictureLogo.TabIndex = 3;
            pictureLogo.TabStop = false;
            // 
            // panZoneVerify
            // 
            panZoneVerify.BackColor = Color.WhiteSmoke;
            panZoneVerify.Controls.Add(lblVaildTime);
            panZoneVerify.Controls.Add(lblTimer);
            panZoneVerify.Controls.Add(btnAgainSend);
            panZoneVerify.Controls.Add(lblNotice);
            panZoneVerify.Controls.Add(panTxtVerify);
            panZoneVerify.Controls.Add(lblVerify);
            panZoneVerify.Controls.Add(lblTitle);
            panZoneVerify.Controls.Add(btnVerify);
            panZoneVerify.Location = new Point(81, 60);
            panZoneVerify.Name = "panZoneVerify";
            panZoneVerify.Size = new Size(317, 495);
            panZoneVerify.TabIndex = 4;
            // 
            // lblVaildTime
            // 
            lblVaildTime.AutoSize = true;
            lblVaildTime.Font = new Font("標楷體", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblVaildTime.Location = new Point(16, 302);
            lblVaildTime.Name = "lblVaildTime";
            lblVaildTime.Size = new Size(87, 16);
            lblVaildTime.TabIndex = 10;
            lblVaildTime.Text = "有效時間: ";
            // 
            // lblTimer
            // 
            lblTimer.AutoSize = true;
            lblTimer.Font = new Font("標楷體", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblTimer.Location = new Point(109, 302);
            lblTimer.Name = "lblTimer";
            lblTimer.Size = new Size(47, 16);
            lblTimer.TabIndex = 5;
            lblTimer.Text = "60 秒";
            // 
            // btnAgainSend
            // 
            btnAgainSend.BackColor = Color.Red;
            btnAgainSend.FlatAppearance.BorderColor = Color.Red;
            btnAgainSend.FlatAppearance.BorderSize = 3;
            btnAgainSend.FlatAppearance.MouseDownBackColor = Color.FromArgb(192, 0, 0);
            btnAgainSend.FlatAppearance.MouseOverBackColor = Color.FromArgb(222, 0, 0);
            btnAgainSend.FlatStyle = FlatStyle.Flat;
            btnAgainSend.Font = new Font("標楷體", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnAgainSend.ForeColor = Color.White;
            btnAgainSend.Location = new Point(180, 290);
            btnAgainSend.Name = "btnAgainSend";
            btnAgainSend.Size = new Size(118, 38);
            btnAgainSend.TabIndex = 9;
            btnAgainSend.Text = "重新發送";
            btnAgainSend.UseVisualStyleBackColor = false;
            btnAgainSend.Click += btnAgainSend_Click;
            // 
            // lblNotice
            // 
            lblNotice.Font = new Font("標楷體", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblNotice.Location = new Point(13, 352);
            lblNotice.Name = "lblNotice";
            lblNotice.Size = new Size(299, 121);
            lblNotice.TabIndex = 8;
            lblNotice.Text = "為了確保您的預約安全，我們已經向您提供的電子郵件地址發送了一封驗證信，請將其中的驗證碼輸入至認證介面中，以完成身份驗證。\r\n驗證成功後，您即可繼續進行預約的下一步作業。驗證碼具有效期限，請於期限內完成驗證。\r\n";
            // 
            // panTxtVerify
            // 
            panTxtVerify.BackColor = Color.DeepSkyBlue;
            panTxtVerify.Controls.Add(txtVerify);
            panTxtVerify.Location = new Point(13, 174);
            panTxtVerify.Name = "panTxtVerify";
            panTxtVerify.Size = new Size(288, 34);
            panTxtVerify.TabIndex = 7;
            // 
            // lblVerify
            // 
            lblVerify.AutoSize = true;
            lblVerify.Font = new Font("標楷體", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblVerify.Location = new Point(13, 134);
            lblVerify.Name = "lblVerify";
            lblVerify.Size = new Size(76, 21);
            lblVerify.TabIndex = 6;
            lblVerify.Text = "驗證碼";
            // 
            // lblTitle
            // 
            lblTitle.AutoSize = true;
            lblTitle.Font = new Font("標楷體", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblTitle.Location = new Point(87, 78);
            lblTitle.Name = "lblTitle";
            lblTitle.Size = new Size(154, 24);
            lblTitle.TabIndex = 5;
            lblTitle.Text = "電子郵件認證";
            // 
            // timer1
            // 
            timer1.Interval = 1000;
            timer1.Tick += timer1_Tick;
            // 
            // Verify
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(483, 583);
            Controls.Add(pictureLogo);
            Controls.Add(panZoneVerify);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "Verify";
            StartPosition = FormStartPosition.CenterParent;
            Text = "小歇一刻K書中心- 電子郵件驗證";
            ((System.ComponentModel.ISupportInitialize)pictureLogo).EndInit();
            panZoneVerify.ResumeLayout(false);
            panZoneVerify.PerformLayout();
            panTxtVerify.ResumeLayout(false);
            panTxtVerify.PerformLayout();
            ResumeLayout(false);
        }

        #endregion
        private TextBox txtVerify;
        private Button btnVerify;
        private PictureBox pictureLogo;
        private Panel panZoneVerify;
        private Label lblTitle;
        private Label lblVerify;
        private Panel panTxtVerify;
        private Label lblNotice;
        private Label lblTimer;
        private Button btnAgainSend;
        private Label lblVaildTime;
        private System.Windows.Forms.Timer timer1;
    }
}