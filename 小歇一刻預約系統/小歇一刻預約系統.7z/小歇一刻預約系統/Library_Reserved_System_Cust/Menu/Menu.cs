﻿using System.Drawing;
using System.Text.Json;
namespace Library_Reserved_System_Cust
{
    public partial class Menu : Form
    {
        //數量 + - 之粉刷筆,顏色
        Brush brushSub = new SolidBrush(Color.LightGray), brushAdd = new SolidBrush(Color.LightGray);
        Pen pen = new Pen(Color.Black, 4); //數量 + - 繪製
        string JsonDB_Path = "..//..//..//..//JsonDB/Menu/"; //菜單路徑
        List<object>? itemJudge = new List<object>(); //確保顧客不可重入加入相同餐點名稱
        Food? food; //提供更改菜單讀取 提取資料到gridMenu 重複使用
        public Menu()
        {
            InitializeComponent();
            setPanel();
            setButton();
            readMenu("Hamburger.ndjson");
        }
        //依據主題選擇對應菜單 EX:Hamburger
        private void readMenu(string menu)
        {
            //刷新
            gridMenu.Rows.Clear();
            lblNum.Text = "1"; //數量變為1 邏輯上更正
            try
            {
                //依據主題載入對應菜單
                foreach (var line in File.ReadLines(JsonDB_Path + menu))
                {
                    food = JsonSerializer.Deserialize<Food>(line);
                    gridMenu.Rows.Add(food.Name, food.Price);
                }
            }
            catch (Exception ex)
            {
                //如果菜單不存在 代表是空有按鈕 沒東西
                gridMenu.Rows.Add("敬請期待");
            }
            // 菜單及顧客加入的 Grid 的點選Select反藍 都清除 邏輯上更正
            gridOrder.ClearSelection();
            gridMenu.ClearSelection();
        }
        //設置餐點主題按鈕按下後 依據按下的對象來去呼叫方法載入對應名稱(主題)的菜單
        private void setButton()
        {
            btnHamburger.Click += btnClick;
            btnEggroll.Click += btnClick;
            btnSandwich.Click += btnClick;
            btnNoodle.Click += btnClick;
            btnDrink.Click += btnClick;
            btnOther.Click += btnClick;
        }
        //依據被按下的餐點主題按鈕是誰 取得Name後 當作參數來去更新菜單
        private void btnClick(object? sender, EventArgs e)
        {
            Button? btn = (Button?)sender;
            if (btn != null)
                readMenu(btn.Name.Substring(3) + ".ndjson");
        }
        //加,減按鈕與滑鼠上的互動 改對應筆刷顏色
        private void setPanel()
        {
            panAdd.MouseEnter += panEnterOrUpColor;
            panAdd.MouseDown += panDownColor;
            panAdd.MouseLeave += panLeaveColor;
            panAdd.MouseUp += panEnterOrUpColor;
            panAdd.Paint += panPaint;

            panSub.MouseEnter += panEnterOrUpColor;
            panSub.MouseDown += panDownColor;
            panSub.MouseUp += panEnterOrUpColor;
            panSub.MouseLeave += panLeaveColor;
            panSub.Paint += panPaint;
        }
        //滑鼠進入或按下且"放開" 加,減按鈕 改對應筆刷顏色
        private void panEnterOrUpColor(object? sender, EventArgs e)
        {
            Panel? panel = (Panel?)sender;
            if (panel != null)
            {
                if (panel.Name == "panAdd") brushAdd = new SolidBrush(Color.Silver);
                else brushSub = new SolidBrush(Color.Silver);
                panel.Invalidate();
            }
        }
        //按下加,減按鈕 改對應筆刷顏色 且數量更改
        private void panDownColor(object? sender, EventArgs e)
        {
            if (gridMenu.SelectedRows.Count <= 0) MessageBox.Show("請選擇加入項目", "注意", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            else
            {
                Panel? panel = (Panel?)sender;
                if (panel != null)
                {
                    if (panel.Name == "panAdd")
                    {
                        lblNum.Text = Convert.ToString(Convert.ToInt32(lblNum.Text) + 1);
                        brushAdd = new SolidBrush(Color.DarkGray);
                    }
                    else
                    {
                        lblNum.Text = Convert.ToString(Convert.ToInt32(lblNum.Text) - 1);
                        brushSub = new SolidBrush(Color.DarkGray);
                    }
                    panel.Invalidate();
                }
            }
        }
        //離開加,減按鈕 改對應筆刷顏色 且數量更改
        private void panLeaveColor(object? sender, EventArgs e)
        {
            Panel? panel = (Panel?)sender;
            if (panel != null)
            {
                if (panel.Name == "panAdd") brushAdd = new SolidBrush(Color.LightGray);
                else brushSub = new SolidBrush(Color.LightGray);
                panel.Invalidate();
            }
        }
        //繪製加,減按鈕 依據筆刷顏色及畫筆顏色
        private void panPaint(object? sender, PaintEventArgs e)
        {
            Panel? panel = (Panel?)sender;
            if (panel != null)
            {
                if (panel.Name == "panAdd")
                {
                    e.Graphics.FillEllipse(brushAdd, 5, 0, 40, 40);
                    e.Graphics.DrawLine(pen, 25, 4, 25, 35);
                }
                else
                    e.Graphics.FillEllipse(brushSub, 5, 0, 40, 40);
                e.Graphics.DrawLine(pen, 10, 20, 40, 20);
            }
        }
        //當數量更改時 檢查數字是否為1 若為1 則減法Panel消失 數量最低維持1 , 若超過則出現
        private void lblNum_TextChanged(object sender, EventArgs e)
        {
            if (lblNum.Text == "1") panSub.Visible = false;
            else panSub.Visible = true;
        }
        //介面關閉要做的 檢查是否是透過按鈕結束的 如果是 正常關閉 如果不是則將主程式也一併一起結束
        private void Menu_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (this.DialogResult != DialogResult.OK)
                Environment.Exit(0);
        }
        //邏輯上修正 若gridMenu已經有選項且點選別的餐點名稱 數量要刷新 ,同時確保只有被點下的選項反藍 若gridOrder有選項反藍 也會邏輯清除
        private void gridMenu_SelectionChanged(object sender, EventArgs e)
        {
            lblNum.Text = "1";
            if (gridOrder.SelectedRows.Count > 0 && gridMenu.SelectedRows.Count > 0) gridOrder.ClearSelection();
        }
        //邏輯上修正 若gridOrder被點選 若gridMenu有選項反藍 邏輯清除
        private void gridOrder_SelectionChanged(object sender, EventArgs e)
        {
            if (gridMenu.SelectedRows.Count > 0 && gridOrder.SelectedRows.Count > 0) gridMenu.ClearSelection();
        }
        //加入按鈕按下
        private void btnOk_Click(object sender, EventArgs e)
        {
            if (gridMenu.SelectedRows.Count <= 0) MessageBox.Show("請選擇加入項目", "注意", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            else
            {
                //依據點選的餐點讀取Ceil 用以更新右邊GridOrder內容
                foreach (DataGridViewRow orderItem in gridMenu.SelectedRows)
                {
                    if (!itemJudge.Contains(orderItem.Cells[0].Value))
                    {
                        itemJudge.Add(orderItem.Cells[0].Value);
                        int subTotal = (int)orderItem.Cells[1].Value * int.Parse(lblNum.Text);
                        gridOrder.Rows.Add(orderItem.Cells[0].Value, orderItem.Cells[1].Value, byte.Parse(lblNum.Text), subTotal);
                        gridMenu.ClearSelection();
                        gridOrder.ClearSelection();
                        lblTotalNum.Text = Convert.ToString(Convert.ToInt32(lblTotalNum.Text) + subTotal);
                    }
                    else
                        MessageBox.Show("該項目已加入清單!", "注意", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
        }
        //刪除按鈕按下
        private void btnDel_Click(object sender, EventArgs e)
        {
            if (gridOrder.SelectedRows.Count <= 0) MessageBox.Show("請選擇刪除項目", "注意", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            else
            {
                itemJudge.Remove(gridOrder.SelectedRows[0].Cells[0].Value);
                lblTotalNum.Text = Convert.ToString(Convert.ToInt32(lblTotalNum.Text) - (int)gridOrder.SelectedRows[0].Cells[3].Value);
                gridOrder.Rows.Remove(gridOrder.SelectedRows[0]);
                gridOrder.ClearSelection();
            }
        }
        //介面載入完成 邏輯上清除預設第一個餐點反藍 (可有可無)
        private void Menu_Load(object sender, EventArgs e)
        {
            gridMenu.Rows[0].Selected = false;
        }
        //送出按鈕按下
        private void btnSend_Click(object sender, EventArgs e)
        {
            Smtp smtp = new Smtp(); //建立SMTP物件 用來寄送預約結果給預約者
            Program.customer.FoodInfos = new List<FoodInfo>(itemJudge.Count); //建立FoodInfos 物件保存預約者預約餐點的資訊
            Program.customer.Comment = txtComment.Text;
            foreach (DataGridViewRow item in gridOrder.Rows)
            {
                int? price = (int)item.Cells[1].Value;
                byte? qty = (byte)item.Cells[2].Value;
                int? subtotal = (int)item.Cells[3].Value;
                Program.customer.FoodInfos.Add(new FoodInfo(item.Cells[0].Value.ToString(), price, qty));
            }
            smtp.buildReservedHTML(); //建立預約明細之HTML內容 
            smtp.buildRemindHTML();//建立提醒之HTML內容
            smtp.sendReservedGmail(); //寄送GMail
            Program.JsonDB_Path += Program.Floor + "/" + Program.SeatID + ".ndjson";
            var Encode = new JsonSerializerOptions { Encoder = System.Text.Encodings.Web.JavaScriptEncoder.UnsafeRelaxedJsonEscaping };
            File.AppendAllText(Program.JsonDB_Path, JsonSerializer.Serialize(Program.customer, Encode) + Environment.NewLine);
            this.DialogResult = DialogResult.OK;
            this.Close();
        }
        private void txtComment_Click(object sender, EventArgs e)
        {
            gridMenu.ClearSelection();
            gridOrder.ClearSelection();
        }
    }
}
