﻿using System.Text.Json;
namespace Library_Reserved_System_Cust
{
    public partial class FirstF : Form
    {
        CheckBox[] checkbox; //紀錄8個時段 供後續重複使用
        string JsonDB_Path = "..//..//..//..//JsonDB//";  //資料庫路徑
        public FirstF()
        {
            InitializeComponent();
            loadSeatID();
            checkbox = Controls.OfType<CheckBox>().Reverse().ToArray();  //依據習慣重checkbox1 開始
            comboSeat.SelectedIndex = 0;
            loadSeatTime("A1", date.Value.ToString("yyyy/MM/dd"));
        }
        // 載入 一樓 座位ID
        private void loadSeatID()
        {
            foreach (var item in File.ReadAllLines(JsonDB_Path + "SeatID//Floor1.txt"))
                comboSeat.Items.Add(item);
        }
        // 載入依據選擇的座位及日期 提供可選時段
        private void loadSeatTime(string? seatID, string selectDate)
        {
            // 每次更換座位重新刷新checkbox 已"超過"當下時段當然不可預約了
            foreach (CheckBox checkb in checkbox)
            {
                checkb.Checked = false;
                if (date.Value.Date.AddHours(Convert.ToInt32(checkb.Text.Substring(6,2))) < DateTime.Now)
                    checkb.Enabled = false;
                else
                    checkb.Enabled = true;
            }
            // 將已經預約時段 Disable
            if (seatID != null)
            {
                foreach (var line in File.ReadLines(JsonDB_Path + "Reserved/Floor1/"+ seatID + ".ndjson"))
                {
                    Customer? id = JsonSerializer.Deserialize<Customer>(line);
                    if (id != null && id.Date == selectDate)
                        foreach (int time in id.Time)
                            checkbox[time - 49].Enabled = false;
                }
            }
        }
        // 座位ID 更換 重新刷新可選時段
        private void comboSeat_SelectedIndexChanged(object sender, EventArgs e)
        {
            loadSeatTime(comboSeat.SelectedItem?.ToString(), date.Value.ToString("yyyy/MM/dd"));
        }
        // 日期更換 重新刷新可選時段
        private void date_ValueChanged(object sender, EventArgs e)
        {
            loadSeatTime(comboSeat.SelectedItem?.ToString(), date.Value.ToString("yyyy/MM/dd"));
        }
        //下一步按鈕按下 確保時段已經選擇 否則報錯
        private void btnNext_Click(object sender, EventArgs e)
        {
            Program.customer.Time = "";
            for (int i = 0; i < checkbox.Length; i++)
                if (checkbox[i].Checked) Program.customer.Time += (i + 1).ToString();
            if (Program.customer.Time.Length > 0)
            {
                Program.SeatID = comboSeat.SelectedItem?.ToString();
                Program.customer.Date = date.Value.ToString("yyyy/MM/dd");
                DialogResult = DialogResult.OK;
                Close();
            }
            else
                MessageBox.Show("請選擇時段!", "注意", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
        //視窗點擊 要使所有物件失去焦點
        private void FirstF_Click(object sender, EventArgs e)
        {
            ActiveControl = null;
        }
        //介面關閉要做的 檢查是否是透過按鈕結束的 如果是 正常關閉 如果不是則將主程式也一併一起結束
        private void FirstF_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (DialogResult != DialogResult.OK)
                Environment.Exit(0);
        }
    }
}
