﻿using System.Text.Json.Serialization;
public class Food //餐點類別 
{
  [JsonPropertyOrder(0)]
  public string? Name { get; set; } //餐點名稱
  [JsonPropertyOrder(1)]
  public int? Price { get; set; } //餐點單價
}

