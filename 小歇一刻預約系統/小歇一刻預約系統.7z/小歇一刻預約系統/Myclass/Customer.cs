﻿using System.Text.Json.Serialization;
public class Customer //顧客類別
{
    public string? Name { get; set; } //預約者姓名 
    public string? Phone { get; set; } //預約者電話
    public List<FoodInfo>? FoodInfos { get; set; } //預約餐點之集合物件
    public string? Date { get; set; } //預約日期 格式: yyyy/mm/dd 
    public string? Time { get; set; } //預約時段 ex 123 (時段1,2,3)
    public string? Comment { get; set; } //預約者的留言或建議
    public bool IsChecked { get; set; } //預約者是否報到
}
public class FoodInfo : Food //預定餐點詳細資訊 繼承 餐點類別
{
  [JsonPropertyOrder(2)]
  public byte? Amount { get; set; } // 預定該餐點項目的數量
  public FoodInfo(string? name, int? price, byte? amount)
  {
     this.Name = name;
     this.Price = price;
     this.Amount = amount;
  }
}

