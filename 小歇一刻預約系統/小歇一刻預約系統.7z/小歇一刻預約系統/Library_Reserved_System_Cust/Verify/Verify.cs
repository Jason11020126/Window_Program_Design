﻿namespace Library_Reserved_System_Cust
{
    public partial class Verify : Form
    {
        string captcha = "";  //驗證碼比較用
        byte countDownTime = 60; //驗證碼有效時間倒數
        public Verify()
        {
            InitializeComponent();
            clearTxtFocus(this.Controls);
            SendEmail();
        }
        //送出驗證信
        private void SendEmail()
        {
            Smtp smtp = new Smtp();
            generateCaptcha();
            smtp.buildVerifyHTML(captcha);
            smtp.sendVerifyGmail();
            OpenTimer();
        }
        //開始倒數計時驗證碼有效時間 顯示倒數計時時間 禁用再次寄送(邏輯判斷)
        private void OpenTimer()
        {
            btnAgainSend.Visible = false;
            lblVaildTime.Visible = true;
            timer1.Enabled = true;
        }
        //結束倒數計時驗證碼有效時間 隱藏倒數計時時間 啟用再次寄送(邏輯判斷)
        private void CloseTimer()
        {
            btnAgainSend.Visible = true;
            lblVaildTime.Visible = false;
            timer1.Enabled = false;
        }
        //互動設計 當點選其他地方時 要失去焦點 (非必要)
        private void clearTxtFocus(Control.ControlCollection Controls)
        {
            foreach (Control control in Controls)
            {
                // 避免綁到 TextBox 本身
                if (!(control is TextBox))
                {
                    control.Click += (s, e) =>
                    {
                        this.ActiveControl = null; // 清除焦點
                    };
                }

                // 如果有子控制項（例如 Panel 裡面的 Button）
                if (control.HasChildren)
                    clearTxtFocus(control.Controls);
            }
            //form自身也要加上
            this.Click += (s, e) => { this.ActiveControl = null; };
        }

        private void txtVerify_Leave(object sender, EventArgs e)
        {
            panTxtVerify.BackColor = Color.SkyBlue;
        }

        private void txtVerify_Click(object sender, EventArgs e)
        {
            panTxtVerify.BackColor = Color.Yellow;
        }
        //驗證 驗證碼是否正確
        private void btnVerify_Click(object sender, EventArgs e)
        {
            if (txtVerify.Text == captcha && btnAgainSend.Visible == false)
            {
                MessageBox.Show("驗證成功","通知", MessageBoxButtons.OK,MessageBoxIcon.Information);
                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            else 
                MessageBox.Show("驗證碼錯誤!! 請再次嘗試", "通知", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        //生成驗證碼 四位數 每一位數 會先判斷要什麼類型的字元(數字、大小寫英文)後 再去隨機產生對應的亂數值
        private void generateCaptcha()
        {
            captcha = "";
            for (int i = 0; i < 4; i++)
            {
                int asciiType = new Random().Next(0, 3); //0 數字, 1 小寫英文, 2 大寫英文 
                if (asciiType == 0)
                    captcha += Convert.ToChar(new Random().Next(48, 58));
                else if (asciiType == 1)
                    captcha += Convert.ToChar(new Random().Next(97, 123));
                else
                    captcha += Convert.ToChar(new Random().Next(65, 91));
            }
        }
        //顯示驗證碼剩餘有效時間
        private void timer1_Tick(object sender, EventArgs e)
        {
            if (--countDownTime == 0)
            {
                countDownTime = 60;
                lblTimer.Text = "";
                CloseTimer();
            }
            else lblTimer.Text = $"{countDownTime} 秒";
        }
        //重發驗證碼
        private void btnAgainSend_Click(object sender, EventArgs e)
        {
            SendEmail();
        }
    }
}
