using System.Text.Json;
namespace Library_Reserved_System_AD
{
    public partial class Reserved : Form
    {
        List<Customer> Customers = new List<Customer>(); //保存符合日期及預約位置的預約者資訊
        string JsonDB_Path = "..//..//..//../JsonDB//"; //讀取路徑
        char[] time = new char[8]; //時段陣列 用以暫存該預約者 每個時段有無預約
        Customer? customer = null;
        public Reserved()
        {
            InitializeComponent();
            comboFloor.SelectedIndexChanged += loadSeatID;
            comboSeat.SelectedIndexChanged += loadReservedInfo;
            date.ValueChanged += loadReservedInfo;
            comboFloor.SelectedIndex = 0;
        }
        //根據樓層顯示對應的SeatID
        private void loadSeatID(object? sender, EventArgs e)
        {
            comboSeat.Items.Clear();
            foreach (var item in File.ReadAllLines(JsonDB_Path + $"SeatID//Floor{comboFloor.SelectedIndex + 1}.txt"))
                comboSeat.Items.Add(item);
            comboSeat.SelectedIndex = 0;
        }
        //載入預約者資訊 不含餐點 不含留言
        private void loadReservedInfo(object? sender, EventArgs e)
        {
            Customers.Clear();
            gridReservedInfo.Rows.Clear();
            foreach (var item in File.ReadLines(JsonDB_Path + $"Reserved//Floor{comboFloor.SelectedIndex + 1}//{comboSeat.SelectedItem.ToString()}.ndjson"))
            {
                customer = JsonSerializer.Deserialize<Customer>(item);
                if (customer.Date == date.Value.Date.ToString("yyyy/MM/dd"))
                {
                    Array.Clear(time, 0, 8);
                    foreach (var t in customer.Time)
                        time[t - 49] = '\u2713';
                    Customers.Add(JsonSerializer.Deserialize<Customer>(item));
                    gridReservedInfo.Rows.Add(customer.Name, customer.Phone,
                        time[0], time[1], time[2], time[3], time[4], time[5], time[6], time[7]);
                }
            }
        }
        //點擊後失去所有物件焦點 不含grid
        private void Reserved_Click(object sender, EventArgs e)
        {
            this.ActiveControl = null;
        }
        //載入選定預約者預點餐點有哪些 及留言
        private void gridReservedInfo_SelectionChanged(object sender, EventArgs e)
        {
            int? total = 0;
            gridFood.Rows.Clear();
            txtComment.Text = "";
            if (Customers.Count > 0)
            {
                int? subtotal = 0;
                try
                {
                    foreach (FoodInfo food in Customers[gridReservedInfo.SelectedRows[0].Index].FoodInfos)
                    {
                        subtotal = food.Price * food.Amount;
                        gridFood.Rows.Add(food.Name, food.Price, food.Amount, subtotal);
                        total += food.Price * food.Amount;
                    }
                    txtComment.Text = Customers[gridReservedInfo.SelectedRows[0].Index].Comment;
                    gridFood.ClearSelection();
                }
                catch (NullReferenceException ex)
                {
                    gridFood.Rows.Add("無預定餐點");
                }
            }
            lblTotalNum.Text = total.ToString();
        }
    }
}
