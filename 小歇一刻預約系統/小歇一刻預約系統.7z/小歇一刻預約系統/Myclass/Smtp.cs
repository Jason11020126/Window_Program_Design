using System.Net.Mail;
using System.Net;
using System.Text;
using Library_Reserved_System_Cust;
using System.Linq;
public class Smtp
{
    string GoogleID = File.ReadAllText("..//..//..//Resources//SMTP_Account.txt"); //Google 發信帳號
    string TempPwd = File.ReadAllText("..//..//..//Resources//SMTP_Pwd.txt"); //應用程式密碼
    string? ReceiveMail = Program.Gmail; //寄送者Gmail
    string SmtpServer = "smtp.gmail.com"; 
    int SmtpPort = 587;
    Attachment attachment = new Attachment("..//..//..//Resources//小歇一刻地標.jpg");
    MailMessage mms = new MailMessage();
    public Smtp()
    {
        mms.From = new MailAddress(GoogleID);
        mms.Subject = "小歇一刻 K書中心 - 讀書座位預定明細";
        mms.IsBodyHtml = true;
        mms.SubjectEncoding = Encoding.UTF8;
        mms.To.Add(new MailAddress(ReceiveMail));
        mms.Attachments.Add(attachment); //嵌入QR Code
    }
    //建立HTML格式內容 用以給使用者看預約結果 備存 最後嵌入店家座標
    public void buildHTML()
    {
        StringBuilder sb = new StringBuilder();
        int? totalMoney = 0;
        //字典 用來根據預約時段代號(EX 1 2 3)轉換成實際時段
        Dictionary<char, string> reservedTime = new Dictionary<char, string>() {{'1', "08:00-09:00"},{'2', "09:00-10:00"},{'3', "10:00-11:00"},{'4', "11:00-12:00"},
                                                                                {'5', "12:00-13:00"},{'6', "13:00-14:00"},{'7', "14:00-15:00"},{'8', "15:00-16:00"}};
        sb.Append("<strong style='font-size:16px;'>感謝您預定小歇一刻 K書中心之座位~</strong><br>");
        sb.Append("<strong style='font-size:16px;'>以下是您預定的明細如下:</strong><br>");
        sb.Append($"<strong style='font-size:16px;'>👤 預約者姓名: {Program.customer.Name}</strong> <br>");
        sb.Append($"<strong style='font-size:16px;'>📞 預約者電話: {Program.customer.Phone}</strong> <br>");
        sb.Append($"<strong style='font-size:16px;'>🛗 預約樓層: {(Program.Floor == "Floor1" ? 1 : 2)}</strong><br>");
        sb.Append($"<strong style='font-size:16px;'>🆔 預約座位代號: {Program.SeatID}</strong> <br>");
        sb.Append($"<strong style='font-size:16px;'>📆 預約日期: {Program.customer.Date}</strong> <br>");
        sb.Append($"<strong style='font-size:16px;'>🕒 預約時段:</strong><br>");
        foreach (char time in Program.customer.Time)
            sb.Append($"<strong style='font-size:16px;'>{reservedTime[time]}</strong><br>");
        if (Program.customer.FoodInfos?.Count > 0)
        {
            sb.Append($"<strong style='font-size:16px;'>預約餐點:</strong></p>");
            sb.Append("<table border='1' cellspacing='0' style='font-size:16px;'>");
            sb.Append("<tr>");
            sb.Append("<th style='width=50%;'>品項</th>");
            sb.Append("<th style='width=15%;'>單價</th>");
            sb.Append("<th style='width=15%;'>數量</th>");
            sb.Append("<th style='width=20%;'style='width:20%'>小計</th>");
            sb.Append("</tr>");
            foreach (FoodInfo item in Program.customer.FoodInfos)
            {
                totalMoney += item.Price * item.Amount;
                sb.Append($"<tr><td>{item.Name}</td><td>{item.Price}</td><td>{item.Amount}</td><td>{item.Price * item.Amount}</td></tr>");
            }
            sb.Append($"<tr><td colspan='3' align='right'><strong>總計</strong></td><td>{totalMoney}</td></tr>");
            sb.Append("</table>");
        }
        sb.Append("<strong style='font-size:16px;'>📍 本店地址 : 新竹市北區舒陞街3-2號</strong><br><br>");
        sb.Append("<img src=\"cid:" + attachment.ContentId + "\"/>");
        sb.Append($"<br><strong style='font-size:16px;'>如有問題請聯繫電話03-5240180或回覆此郵件</strong><br>");
        mms.Body = sb.ToString();
    }
    //寄送Gmail
    public void sendGmail()
    {
        SmtpClient client = new SmtpClient(SmtpServer, SmtpPort);
        client.EnableSsl = true;
        client.Credentials = new NetworkCredential(GoogleID, TempPwd);//寄送者帳密 小歇一刻  
        client.Send(mms); //寄出信件
        MessageBox.Show("信件已成功寄出！", "成功", MessageBoxButtons.OK, MessageBoxIcon.Information);
    }
    //添加預定日前一天中午12:00 提醒使用者的信件
    public void buildRemindHTML()
    {
        StringBuilder sb = new StringBuilder();
        Dictionary<char, string> reservedTime = new Dictionary<char, string>() {{'1', "08:00-09:00"},{'2', "09:00-10:00"},{'3', "10:00-11:00"},{'4', "11:00-12:00"},
                                                                                {'5', "12:00-13:00"},{'6', "13:00-14:00"},{'7', "14:00-15:00"},{'8', "15:00-16:00"}};
        DateTime RemindDatetime = DateTime.Parse(Program.customer.Date).AddDays(-1);
        RemindDatetime = RemindDatetime.AddHours(12);
        if (RemindDatetime > DateTime.Now)
        {
            sb.Append(RemindDatetime.Date.ToString("yyyy/MM/dd")+"<<<SPLIT>>>");
            foreach (char time in Program.customer.Time)
                sb.Append(reservedTime[time]+"\n");
            mms.Headers.Add("Hidden", sb.ToString());
        }
        else
            mms.Headers.Add("Hidden", "x");
    }
}