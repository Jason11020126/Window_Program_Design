﻿namespace Library_Reserved_System_Cust
{
    partial class Menu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle3 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle8 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle4 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle5 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle6 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle7 = new DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Menu));
            lblTitle = new Label();
            btnSend = new Button();
            btnHamburger = new Button();
            btnEggroll = new Button();
            btnSandwich = new Button();
            btnNoodle = new Button();
            btnDrink = new Button();
            btnOther = new Button();
            lblNum = new Label();
            panNum = new Panel();
            panAdd = new Panel();
            panSub = new Panel();
            btnOk = new Button();
            lblOrderList = new Label();
            btnDel = new Button();
            lblDirectSend = new Label();
            lblTotalTitle = new Label();
            gridMenu = new DataGridView();
            menuItemName = new DataGridViewTextBoxColumn();
            menuItemPrice = new DataGridViewTextBoxColumn();
            gridOrder = new DataGridView();
            orderItemName = new DataGridViewTextBoxColumn();
            orderItemPrice = new DataGridViewTextBoxColumn();
            orderItemAmount = new DataGridViewTextBoxColumn();
            orderItemSubtotal = new DataGridViewTextBoxColumn();
            lblTotalNum = new Label();
            lblDollars = new Label();
            lblMenu = new Label();
            lblCommentTitle = new Label();
            panComment = new Panel();
            txtComment = new TextBox();
            panNum.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)gridMenu).BeginInit();
            ((System.ComponentModel.ISupportInitialize)gridOrder).BeginInit();
            panComment.SuspendLayout();
            SuspendLayout();
            // 
            // lblTitle
            // 
            lblTitle.AutoSize = true;
            lblTitle.Font = new Font("標楷體", 20.25F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            lblTitle.ForeColor = Color.Red;
            lblTitle.Location = new Point(357, 22);
            lblTitle.Name = "lblTitle";
            lblTitle.Size = new Size(463, 27);
            lblTitle.TabIndex = 7;
            lblTitle.Text = "小歇一刻K書中心- 讀書室預約系統";
            // 
            // btnSend
            // 
            btnSend.BackColor = Color.DeepSkyBlue;
            btnSend.FlatAppearance.BorderColor = Color.DeepSkyBlue;
            btnSend.FlatAppearance.BorderSize = 3;
            btnSend.FlatAppearance.MouseDownBackColor = Color.RoyalBlue;
            btnSend.FlatAppearance.MouseOverBackColor = Color.DodgerBlue;
            btnSend.FlatStyle = FlatStyle.Flat;
            btnSend.Font = new Font("標楷體", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnSend.ForeColor = Color.White;
            btnSend.Location = new Point(1053, 609);
            btnSend.Name = "btnSend";
            btnSend.Size = new Size(92, 44);
            btnSend.TabIndex = 16;
            btnSend.Text = "送出";
            btnSend.UseVisualStyleBackColor = false;
            btnSend.Click += btnSend_Click;
            // 
            // btnHamburger
            // 
            btnHamburger.BackColor = Color.FromArgb(224, 224, 224);
            btnHamburger.FlatAppearance.BorderColor = Color.DarkGray;
            btnHamburger.FlatAppearance.BorderSize = 2;
            btnHamburger.FlatAppearance.MouseDownBackColor = Color.Gray;
            btnHamburger.FlatAppearance.MouseOverBackColor = Color.Silver;
            btnHamburger.FlatStyle = FlatStyle.Flat;
            btnHamburger.Font = new Font("標楷體", 14.25F);
            btnHamburger.Location = new Point(60, 120);
            btnHamburger.Name = "btnHamburger";
            btnHamburger.Size = new Size(127, 32);
            btnHamburger.TabIndex = 17;
            btnHamburger.Text = "漢堡";
            btnHamburger.UseVisualStyleBackColor = false;
            // 
            // btnEggroll
            // 
            btnEggroll.BackColor = Color.FromArgb(224, 224, 224);
            btnEggroll.FlatAppearance.BorderColor = Color.DarkGray;
            btnEggroll.FlatAppearance.BorderSize = 2;
            btnEggroll.FlatAppearance.MouseDownBackColor = Color.Gray;
            btnEggroll.FlatAppearance.MouseOverBackColor = Color.Silver;
            btnEggroll.FlatStyle = FlatStyle.Flat;
            btnEggroll.Font = new Font("標楷體", 14.25F);
            btnEggroll.Location = new Point(243, 120);
            btnEggroll.Name = "btnEggroll";
            btnEggroll.Size = new Size(127, 32);
            btnEggroll.TabIndex = 18;
            btnEggroll.Text = "蛋餅";
            btnEggroll.UseVisualStyleBackColor = false;
            // 
            // btnSandwich
            // 
            btnSandwich.BackColor = Color.FromArgb(224, 224, 224);
            btnSandwich.FlatAppearance.BorderColor = Color.DarkGray;
            btnSandwich.FlatAppearance.BorderSize = 2;
            btnSandwich.FlatAppearance.MouseDownBackColor = Color.Gray;
            btnSandwich.FlatAppearance.MouseOverBackColor = Color.Silver;
            btnSandwich.FlatStyle = FlatStyle.Flat;
            btnSandwich.Font = new Font("標楷體", 14.25F);
            btnSandwich.Location = new Point(426, 120);
            btnSandwich.Name = "btnSandwich";
            btnSandwich.Size = new Size(127, 32);
            btnSandwich.TabIndex = 19;
            btnSandwich.Text = "吐司";
            btnSandwich.UseVisualStyleBackColor = false;
            // 
            // btnNoodle
            // 
            btnNoodle.BackColor = Color.FromArgb(224, 224, 224);
            btnNoodle.FlatAppearance.BorderColor = Color.DarkGray;
            btnNoodle.FlatAppearance.BorderSize = 2;
            btnNoodle.FlatAppearance.MouseDownBackColor = Color.Gray;
            btnNoodle.FlatAppearance.MouseOverBackColor = Color.Silver;
            btnNoodle.FlatStyle = FlatStyle.Flat;
            btnNoodle.Font = new Font("標楷體", 14.25F);
            btnNoodle.Location = new Point(609, 120);
            btnNoodle.Name = "btnNoodle";
            btnNoodle.Size = new Size(127, 32);
            btnNoodle.TabIndex = 20;
            btnNoodle.Text = "麵食";
            btnNoodle.UseVisualStyleBackColor = false;
            // 
            // btnDrink
            // 
            btnDrink.BackColor = Color.FromArgb(224, 224, 224);
            btnDrink.FlatAppearance.BorderColor = Color.DarkGray;
            btnDrink.FlatAppearance.BorderSize = 2;
            btnDrink.FlatAppearance.MouseDownBackColor = Color.Gray;
            btnDrink.FlatAppearance.MouseOverBackColor = Color.Silver;
            btnDrink.FlatStyle = FlatStyle.Flat;
            btnDrink.Font = new Font("標楷體", 14.25F);
            btnDrink.Location = new Point(792, 120);
            btnDrink.Name = "btnDrink";
            btnDrink.Size = new Size(127, 32);
            btnDrink.TabIndex = 22;
            btnDrink.Text = "飲料";
            btnDrink.UseVisualStyleBackColor = false;
            // 
            // btnOther
            // 
            btnOther.BackColor = Color.FromArgb(224, 224, 224);
            btnOther.FlatAppearance.BorderColor = Color.DarkGray;
            btnOther.FlatAppearance.BorderSize = 2;
            btnOther.FlatAppearance.MouseDownBackColor = Color.Gray;
            btnOther.FlatAppearance.MouseOverBackColor = Color.Silver;
            btnOther.FlatStyle = FlatStyle.Flat;
            btnOther.Font = new Font("標楷體", 14.25F);
            btnOther.Location = new Point(975, 120);
            btnOther.Name = "btnOther";
            btnOther.Size = new Size(127, 32);
            btnOther.TabIndex = 23;
            btnOther.Text = "其他";
            btnOther.UseVisualStyleBackColor = false;
            // 
            // lblNum
            // 
            lblNum.BackColor = Color.White;
            lblNum.Font = new Font("標楷體", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblNum.Location = new Point(89, 16);
            lblNum.Name = "lblNum";
            lblNum.Size = new Size(54, 20);
            lblNum.TabIndex = 25;
            lblNum.Text = "1";
            lblNum.TextAlign = ContentAlignment.MiddleRight;
            lblNum.TextChanged += lblNum_TextChanged;
            // 
            // panNum
            // 
            panNum.BackColor = Color.White;
            panNum.Controls.Add(panAdd);
            panNum.Controls.Add(lblNum);
            panNum.Controls.Add(panSub);
            panNum.Location = new Point(462, 246);
            panNum.Name = "panNum";
            panNum.Size = new Size(227, 57);
            panNum.TabIndex = 26;
            // 
            // panAdd
            // 
            panAdd.BackColor = Color.White;
            panAdd.Location = new Point(161, 7);
            panAdd.Name = "panAdd";
            panAdd.Size = new Size(54, 42);
            panAdd.TabIndex = 28;
            // 
            // panSub
            // 
            panSub.BackColor = Color.White;
            panSub.Location = new Point(9, 7);
            panSub.Name = "panSub";
            panSub.Size = new Size(54, 42);
            panSub.TabIndex = 27;
            panSub.Visible = false;
            // 
            // btnOk
            // 
            btnOk.BackColor = Color.DeepSkyBlue;
            btnOk.FlatAppearance.BorderColor = Color.DeepSkyBlue;
            btnOk.FlatAppearance.BorderSize = 3;
            btnOk.FlatAppearance.MouseDownBackColor = Color.RoyalBlue;
            btnOk.FlatAppearance.MouseOverBackColor = Color.DodgerBlue;
            btnOk.FlatStyle = FlatStyle.Flat;
            btnOk.Font = new Font("標楷體", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnOk.ForeColor = Color.White;
            btnOk.Location = new Point(532, 315);
            btnOk.Name = "btnOk";
            btnOk.Size = new Size(92, 44);
            btnOk.TabIndex = 28;
            btnOk.Text = "加入";
            btnOk.UseVisualStyleBackColor = false;
            btnOk.Click += btnOk_Click;
            // 
            // lblOrderList
            // 
            lblOrderList.Font = new Font("標楷體", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblOrderList.ForeColor = Color.Green;
            lblOrderList.Location = new Point(838, 164);
            lblOrderList.Name = "lblOrderList";
            lblOrderList.Size = new Size(134, 21);
            lblOrderList.TabIndex = 29;
            lblOrderList.Text = "購 物 清 單";
            // 
            // btnDel
            // 
            btnDel.BackColor = Color.DeepSkyBlue;
            btnDel.FlatAppearance.BorderColor = Color.DeepSkyBlue;
            btnDel.FlatAppearance.BorderSize = 3;
            btnDel.FlatAppearance.MouseDownBackColor = Color.RoyalBlue;
            btnDel.FlatAppearance.MouseOverBackColor = Color.DodgerBlue;
            btnDel.FlatStyle = FlatStyle.Flat;
            btnDel.Font = new Font("標楷體", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnDel.ForeColor = Color.White;
            btnDel.Location = new Point(532, 373);
            btnDel.Name = "btnDel";
            btnDel.Size = new Size(92, 44);
            btnDel.TabIndex = 30;
            btnDel.Text = "刪除";
            btnDel.UseVisualStyleBackColor = false;
            btnDel.Click += btnDel_Click;
            // 
            // lblDirectSend
            // 
            lblDirectSend.AutoSize = true;
            lblDirectSend.Font = new Font("標楷體", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblDirectSend.ForeColor = Color.Red;
            lblDirectSend.Location = new Point(462, 79);
            lblDirectSend.Name = "lblDirectSend";
            lblDirectSend.Size = new Size(230, 21);
            lblDirectSend.TabIndex = 31;
            lblDirectSend.Text = "若不需購買可直接送出";
            // 
            // lblTotalTitle
            // 
            lblTotalTitle.Font = new Font("標楷體", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblTotalTitle.ForeColor = Color.Black;
            lblTotalTitle.Location = new Point(462, 439);
            lblTotalTitle.Name = "lblTotalTitle";
            lblTotalTitle.Size = new Size(262, 21);
            lblTotalTitle.TabIndex = 32;
            lblTotalTitle.Text = "總計:";
            // 
            // gridMenu
            // 
            gridMenu.AllowUserToAddRows = false;
            gridMenu.AllowUserToDeleteRows = false;
            gridMenu.AllowUserToResizeColumns = false;
            gridMenu.AllowUserToResizeRows = false;
            gridMenu.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            gridMenu.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCellsExceptHeaders;
            gridMenu.BackgroundColor = SystemColors.ControlLightLight;
            dataGridViewCellStyle1.Alignment = DataGridViewContentAlignment.TopLeft;
            dataGridViewCellStyle1.BackColor = SystemColors.HighlightText;
            dataGridViewCellStyle1.Font = new Font("標楷體", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            dataGridViewCellStyle1.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = SystemColors.HighlightText;
            dataGridViewCellStyle1.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = DataGridViewTriState.True;
            gridMenu.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            gridMenu.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            gridMenu.Columns.AddRange(new DataGridViewColumn[] { menuItemName, menuItemPrice });
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.TopLeft;
            dataGridViewCellStyle2.BackColor = SystemColors.Window;
            dataGridViewCellStyle2.Font = new Font("標楷體", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            dataGridViewCellStyle2.ForeColor = SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.False;
            gridMenu.DefaultCellStyle = dataGridViewCellStyle2;
            gridMenu.GridColor = Color.Black;
            gridMenu.Location = new Point(60, 198);
            gridMenu.MultiSelect = false;
            gridMenu.Name = "gridMenu";
            gridMenu.ReadOnly = true;
            gridMenu.RowHeadersVisible = false;
            gridMenu.RowTemplate.Height = 10;
            gridMenu.ScrollBars = ScrollBars.Vertical;
            gridMenu.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            gridMenu.Size = new Size(405, 219);
            gridMenu.TabIndex = 0;
            gridMenu.TabStop = false;
            gridMenu.SelectionChanged += gridMenu_SelectionChanged;
            // 
            // menuItemName
            // 
            menuItemName.FillWeight = 70F;
            menuItemName.HeaderText = "商品名稱";
            menuItemName.Name = "menuItemName";
            menuItemName.ReadOnly = true;
            // 
            // menuItemPrice
            // 
            menuItemPrice.FillWeight = 30F;
            menuItemPrice.HeaderText = "單價";
            menuItemPrice.Name = "menuItemPrice";
            menuItemPrice.ReadOnly = true;
            // 
            // gridOrder
            // 
            gridOrder.AllowUserToAddRows = false;
            gridOrder.AllowUserToDeleteRows = false;
            gridOrder.AllowUserToResizeColumns = false;
            gridOrder.AllowUserToResizeRows = false;
            gridOrder.BackgroundColor = SystemColors.ControlLightLight;
            dataGridViewCellStyle3.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = SystemColors.HighlightText;
            dataGridViewCellStyle3.Font = new Font("標楷體", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            dataGridViewCellStyle3.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = SystemColors.HighlightText;
            dataGridViewCellStyle3.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = DataGridViewTriState.False;
            gridOrder.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle3;
            gridOrder.ColumnHeadersHeight = 25;
            gridOrder.Columns.AddRange(new DataGridViewColumn[] { orderItemName, orderItemPrice, orderItemAmount, orderItemSubtotal });
            dataGridViewCellStyle8.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = SystemColors.Window;
            dataGridViewCellStyle8.Font = new Font("標楷體", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            dataGridViewCellStyle8.ForeColor = SystemColors.ControlText;
            dataGridViewCellStyle8.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle8.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = DataGridViewTriState.False;
            gridOrder.DefaultCellStyle = dataGridViewCellStyle8;
            gridOrder.GridColor = Color.Black;
            gridOrder.Location = new Point(687, 198);
            gridOrder.MultiSelect = false;
            gridOrder.Name = "gridOrder";
            gridOrder.ReadOnly = true;
            gridOrder.RowHeadersVisible = false;
            gridOrder.ScrollBars = ScrollBars.Vertical;
            gridOrder.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            gridOrder.Size = new Size(415, 233);
            gridOrder.TabIndex = 33;
            gridOrder.TabStop = false;
            gridOrder.SelectionChanged += gridOrder_SelectionChanged;
            // 
            // orderItemName
            // 
            dataGridViewCellStyle4.Alignment = DataGridViewContentAlignment.MiddleCenter;
            orderItemName.DefaultCellStyle = dataGridViewCellStyle4;
            orderItemName.FillWeight = 60F;
            orderItemName.HeaderText = "商品名稱";
            orderItemName.Name = "orderItemName";
            orderItemName.ReadOnly = true;
            orderItemName.Resizable = DataGridViewTriState.False;
            orderItemName.SortMode = DataGridViewColumnSortMode.NotSortable;
            orderItemName.Width = 232;
            // 
            // orderItemPrice
            // 
            dataGridViewCellStyle5.Alignment = DataGridViewContentAlignment.MiddleCenter;
            orderItemPrice.DefaultCellStyle = dataGridViewCellStyle5;
            orderItemPrice.FillWeight = 40F;
            orderItemPrice.HeaderText = "單價";
            orderItemPrice.Name = "orderItemPrice";
            orderItemPrice.ReadOnly = true;
            orderItemPrice.Width = 60;
            // 
            // orderItemAmount
            // 
            dataGridViewCellStyle6.Alignment = DataGridViewContentAlignment.MiddleCenter;
            orderItemAmount.DefaultCellStyle = dataGridViewCellStyle6;
            orderItemAmount.FillWeight = 20F;
            orderItemAmount.HeaderText = "數量";
            orderItemAmount.Name = "orderItemAmount";
            orderItemAmount.ReadOnly = true;
            orderItemAmount.Width = 60;
            // 
            // orderItemSubtotal
            // 
            dataGridViewCellStyle7.Alignment = DataGridViewContentAlignment.MiddleCenter;
            orderItemSubtotal.DefaultCellStyle = dataGridViewCellStyle7;
            orderItemSubtotal.FillWeight = 23F;
            orderItemSubtotal.HeaderText = "小計";
            orderItemSubtotal.Name = "orderItemSubtotal";
            orderItemSubtotal.ReadOnly = true;
            orderItemSubtotal.Width = 60;
            // 
            // lblTotalNum
            // 
            lblTotalNum.Font = new Font("標楷體", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblTotalNum.Location = new Point(519, 439);
            lblTotalNum.Name = "lblTotalNum";
            lblTotalNum.Size = new Size(144, 23);
            lblTotalNum.TabIndex = 34;
            lblTotalNum.Text = "0";
            lblTotalNum.TextAlign = ContentAlignment.MiddleRight;
            // 
            // lblDollars
            // 
            lblDollars.AutoSize = true;
            lblDollars.Font = new Font("標楷體", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblDollars.Location = new Point(660, 441);
            lblDollars.Name = "lblDollars";
            lblDollars.Size = new Size(29, 19);
            lblDollars.TabIndex = 35;
            lblDollars.Text = "元";
            // 
            // lblMenu
            // 
            lblMenu.Font = new Font("標楷體", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblMenu.ForeColor = Color.Green;
            lblMenu.Location = new Point(189, 164);
            lblMenu.Name = "lblMenu";
            lblMenu.Size = new Size(134, 21);
            lblMenu.TabIndex = 36;
            lblMenu.Text = "菜 單";
            lblMenu.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // lblCommentTitle
            // 
            lblCommentTitle.BackColor = Color.Gainsboro;
            lblCommentTitle.Font = new Font("標楷體", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblCommentTitle.Location = new Point(14, 5);
            lblCommentTitle.Name = "lblCommentTitle";
            lblCommentTitle.Size = new Size(1015, 30);
            lblCommentTitle.TabIndex = 37;
            lblCommentTitle.Text = "備註或建議";
            lblCommentTitle.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // panComment
            // 
            panComment.BackColor = Color.Gainsboro;
            panComment.Controls.Add(txtComment);
            panComment.Controls.Add(lblCommentTitle);
            panComment.Location = new Point(60, 473);
            panComment.Name = "panComment";
            panComment.Size = new Size(1042, 130);
            panComment.TabIndex = 38;
            // 
            // txtComment
            // 
            txtComment.Font = new Font("標楷體", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtComment.Location = new Point(14, 38);
            txtComment.Multiline = true;
            txtComment.Name = "txtComment";
            txtComment.PlaceholderText = "有什麼要和我們說的嗎~";
            txtComment.Size = new Size(1015, 89);
            txtComment.TabIndex = 39;
            txtComment.Click += txtComment_Click;
            // 
            // Menu
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.AntiqueWhite;
            ClientSize = new Size(1157, 665);
            Controls.Add(lblMenu);
            Controls.Add(lblDollars);
            Controls.Add(lblTotalNum);
            Controls.Add(gridOrder);
            Controls.Add(gridMenu);
            Controls.Add(lblTotalTitle);
            Controls.Add(lblDirectSend);
            Controls.Add(btnDel);
            Controls.Add(lblOrderList);
            Controls.Add(btnOk);
            Controls.Add(panNum);
            Controls.Add(btnOther);
            Controls.Add(btnDrink);
            Controls.Add(btnNoodle);
            Controls.Add(btnSandwich);
            Controls.Add(btnEggroll);
            Controls.Add(btnHamburger);
            Controls.Add(btnSend);
            Controls.Add(lblTitle);
            Controls.Add(panComment);
            ForeColor = SystemColors.ControlText;
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "Menu";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "小歇一刻K書中心 - 點餐";
            FormClosed += Menu_FormClosed;
            Load += Menu_Load;
            panNum.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)gridMenu).EndInit();
            ((System.ComponentModel.ISupportInitialize)gridOrder).EndInit();
            panComment.ResumeLayout(false);
            panComment.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblTitle;
        private Button btnSend;
        private Button btnHamburger;
        private Button btnEggroll;
        private Button btnSandwich;
        private Button btnNoodle;
        private Button btnDrink;
        private Button btnOther;
        private Label lblNum;
        private Panel panNum;
        private Panel panAdd;
        private Panel panSub;
        private Button btnOk;
        private Label lblOrderList;
        private Button btnDel;
        private Label lblDirectSend;
        private Label lblTotalTitle;
        private DataGridView gridMenu;
        private DataGridView gridOrder;
        private DataGridViewTextBoxColumn menuItemName;
        private DataGridViewTextBoxColumn menuItemPrice;
        private Label lblTotalNum;
        private Label lblDollars;
        private DataGridViewTextBoxColumn orderItemName;
        private DataGridViewTextBoxColumn orderItemPrice;
        private DataGridViewTextBoxColumn orderItemAmount;
        private DataGridViewTextBoxColumn orderItemSubtotal;
        private Label lblMenu;
        private Label lblCommentTitle;
        private Panel panComment;
        private TextBox txtComment;
    }
}