﻿namespace Library_Reserved_System_Cust
{
    public partial class Map : Form
    {
        public Map()
        {
            InitializeComponent();
        }
        private async void Map_Load(object sender, EventArgs e)
        {
            await webMap.EnsureCoreWebView2Async(null); //建立(確保)瀏覽器 WebView2 內部初始化
            string url = "https://www.google.com/maps/place/%E6%98%8E%E6%96%B0%E7%A7%91%E6%8A%80%E5%A4%A7%E5%AD%B8/@24.8641986,120.9880899,818m/data=!3m2!1e3!4b1!4m6!3m5!1s0x34683154faa8283b:0x92cb1c5564a574ef!8m2!3d24.8641986!4d120.9906648!16zL20vMDRtbjJn?entry=ttu&g_ep=EgoyMDI1MDUyMS4wIKXMDSoJLDEwMjExNDUzSAFQAw%3D%3D";
            webMap.CoreWebView2.Navigate(url); //依據URL呈現地圖搜尋結果 導航
        }
        private  void Map_FormClosed(object sender, FormClosedEventArgs e)
        {
            webMap.Dispose();
            webMap = null;
            Thread.Sleep(300);
            Directory.Delete("Library_Reserved_System_Cust.exe.WebView2", true);
        }
    }
}
