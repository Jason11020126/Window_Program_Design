
using System.Text.RegularExpressions;

namespace Library_Reserved_System_Cust
{
    public partial class Login : Form
    {
        int lblEnglishTitle_x; //英文副標題 跑馬燈之x座標

        public Login()
        {
            InitializeComponent();
            setTxt();
            lblMaunal.Text = File.ReadAllText("..//..//..//Resources//Manual.txt"); //讀取操作說明 文檔
            lblInfo.Text = File.ReadAllText("..//..//..//Resources//Info.txt");     //讀取店家資訊 文檔
            lblNotice.Text = File.ReadAllText("..//..//..//Resources//Notice.txt"); //讀取店家注意事項 文檔
        }
        //文字框加上互動事件
        private void setTxt()
        {
            foreach (Panel panel in panLogin.Controls.OfType<Panel>())
            {
                panel.Controls.OfType<TextBox>().First().MouseEnter += TxtMouseEnter;
                panel.Controls.OfType<TextBox>().First().MouseLeave += TxtMouseLeave;
                panel.Controls.OfType<TextBox>().First().Leave += TxtLeave;
                panel.Controls.OfType<TextBox>().First().Click += TxtClick;
            }
        }
        //英文副標題跑馬燈 從右往左 每次x減少8 直到x變為-panel的座標 x變成panel的寬度 重新
        private void timerTitle_Tick(object sender, EventArgs e)
        {
            lblEnglishTitle_x = lblEnglishTitle.Location.X - 8;
            if (lblEnglishTitle_x <= -panEnglishTitle.Size.Width)
                lblEnglishTitle_x = panEnglishTitle.Size.Width;
            lblEnglishTitle.Location = new Point(lblEnglishTitle_x, lblEnglishTitle.Location.Y);
        }
        //視窗點擊 要使所有物件失去焦點
        private void Login_Click(object sender, EventArgs e)
        {
            this.ActiveControl = null;
        }
        //滑鼠進入文字框 改變panel背景色 互動
        private void TxtMouseEnter(object? sender, EventArgs e)
        {
            TextBox? txtbox = (TextBox?)sender;
            if (txtbox != null && txtbox.Parent != null && !txtbox.Focused)
                txtbox.Parent.BackColor = Color.DodgerBlue;
        }
        //滑鼠離開文字框 改變panel背景色 互動
        private void TxtMouseLeave(object? sender, EventArgs e)
        {
            TextBox? txtbox = (TextBox?)sender;
            if (txtbox != null && txtbox.Parent != null && !txtbox.Focused)
                txtbox.Parent.BackColor = Color.FromArgb(100, 255, 255);
        }
        //文字框失去焦點(Ex 第一個框被點後 又點了別框 第一個框所要做的)
        private void TxtLeave(object? sender, EventArgs e)
        {
            TextBox? txtbox = (TextBox?)sender;
            if (txtbox != null && txtbox.Parent != null)
                txtbox.Parent.BackColor = Color.FromArgb(100, 255, 255);
        }
        //點擊文字框
        private void TxtClick(object? sender, EventArgs e)
        {
            TextBox? txtbox = (TextBox?)sender;
            if (txtbox != null && txtbox.Parent != null)
                txtbox.Parent.BackColor = Color.Red;
        }
       
        //進入下一個畫面的按鈕被點擊 檢查邏輯為 1.個資有沒有都被輸入 2.檢查電話格式 3.檢查郵件格式 4.檢查樓層是否有選擇 5.檢查驗證碼
        //確認無誤後才進入夏禕畫面
        private void btnNext_Click(object sender, EventArgs e)
        {
            if (txtName.Text.Length == 0 || txtPhone.Text.Length == 0 || txtGmail.Text.Length == 0)
                MessageBox.Show("預約者資料未填入完整", "注意", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            else if (!Regex.IsMatch(txtPhone.Text, @"^09\d{8}$"))
                MessageBox.Show("電話格式輸入錯誤", "注意", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            else if (!Regex.IsMatch(txtGmail.Text, @"^[a-zA-Z0-9._%+-]+@gmail\.com$"))
                MessageBox.Show("電子郵件輸入錯誤", "注意", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            else if (comboFloor.SelectedIndex == -1)
                MessageBox.Show("請選擇樓層", "注意", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            else
            {
                Program.customer.Name = txtName.Text;
                Program.Gmail = txtGmail.Text;
                Verify verify = new Verify();
                verify.ShowDialog();
                if (verify.DialogResult == DialogResult.OK)
                {
                    Program.customer.Phone = txtPhone.Text;
                    Program.Floor = "Floor" + (comboFloor.SelectedIndex + 1).ToString();
                    this.DialogResult = DialogResult.OK;
                    this.Close();
                }
            }
        }
        //介面關閉要做的 檢查是否是透過按鈕結束的 如果是 正常關閉 如果不是則將主程式也一併一起結束
        private void Login_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (this.DialogResult != DialogResult.OK)
                Environment.Exit(0);
        }
        //查看地圖 產生一個強制回應的地圖介面 原介面先隱藏起來 關閉後才回來
        private void linkMap_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            Map map = new Map();
            map.ShowDialog();
            this.Show();
        }
    }
}
