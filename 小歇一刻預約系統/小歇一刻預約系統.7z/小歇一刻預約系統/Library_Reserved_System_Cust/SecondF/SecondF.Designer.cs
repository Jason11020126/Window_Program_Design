﻿namespace Library_Reserved_System_Cust
{
    partial class SecondF
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SecondF));
            lblChineseTitle = new Label();
            btnNext = new Button();
            tableLayoutPanel1 = new TableLayoutPanel();
            lbltableF3 = new Label();
            lbltableF2 = new Label();
            lbltableF1 = new Label();
            lblFloor = new Label();
            tableLayoutPanel2 = new TableLayoutPanel();
            lbltableG2 = new Label();
            lbltableG1 = new Label();
            tableLayoutPanel3 = new TableLayoutPanel();
            lbltableH2 = new Label();
            lbltableH1 = new Label();
            tableLayoutPanel4 = new TableLayoutPanel();
            lbltableI2 = new Label();
            lbltableI1 = new Label();
            tableLayoutPanel5 = new TableLayoutPanel();
            lbltableJ2 = new Label();
            lbltableJ1 = new Label();
            lblSeat = new Label();
            comboSeat = new ComboBox();
            lblAfterNoon = new Label();
            lblMorning = new Label();
            checkTime8 = new CheckBox();
            checkTime7 = new CheckBox();
            checkTime6 = new CheckBox();
            checkTime5 = new CheckBox();
            checkTime4 = new CheckBox();
            checkTime3 = new CheckBox();
            checkTime2 = new CheckBox();
            checkTime1 = new CheckBox();
            lblDate = new Label();
            date = new DateTimePicker();
            tableLayoutPanel1.SuspendLayout();
            tableLayoutPanel2.SuspendLayout();
            tableLayoutPanel3.SuspendLayout();
            tableLayoutPanel4.SuspendLayout();
            tableLayoutPanel5.SuspendLayout();
            SuspendLayout();
            // 
            // lblChineseTitle
            // 
            lblChineseTitle.AutoSize = true;
            lblChineseTitle.Font = new Font("標楷體", 20.25F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            lblChineseTitle.ForeColor = Color.Red;
            lblChineseTitle.Location = new Point(371, 19);
            lblChineseTitle.Name = "lblChineseTitle";
            lblChineseTitle.Size = new Size(463, 27);
            lblChineseTitle.TabIndex = 6;
            lblChineseTitle.Text = "小歇一刻K書中心- 讀書室預約系統";
            // 
            // btnNext
            // 
            btnNext.BackColor = Color.DeepSkyBlue;
            btnNext.FlatAppearance.BorderColor = Color.DeepSkyBlue;
            btnNext.FlatAppearance.BorderSize = 3;
            btnNext.FlatAppearance.MouseDownBackColor = Color.RoyalBlue;
            btnNext.FlatAppearance.MouseOverBackColor = Color.DodgerBlue;
            btnNext.FlatStyle = FlatStyle.Flat;
            btnNext.Font = new Font("標楷體", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnNext.ForeColor = Color.White;
            btnNext.Location = new Point(1042, 609);
            btnNext.Name = "btnNext";
            btnNext.Size = new Size(103, 44);
            btnNext.TabIndex = 15;
            btnNext.Text = "下一步";
            btnNext.UseVisualStyleBackColor = false;
            btnNext.Click += btnNext_Click;
            // 
            // tableLayoutPanel1
            // 
            tableLayoutPanel1.Anchor = AnchorStyles.None;
            tableLayoutPanel1.BackColor = Color.White;
            tableLayoutPanel1.CellBorderStyle = TableLayoutPanelCellBorderStyle.OutsetPartial;
            tableLayoutPanel1.ColumnCount = 3;
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33.986927F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33.3333321F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 32.35294F));
            tableLayoutPanel1.Controls.Add(lbltableF3, 2, 0);
            tableLayoutPanel1.Controls.Add(lbltableF2, 1, 0);
            tableLayoutPanel1.Controls.Add(lbltableF1, 0, 0);
            tableLayoutPanel1.Location = new Point(87, 118);
            tableLayoutPanel1.Name = "tableLayoutPanel1";
            tableLayoutPanel1.RowCount = 1;
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tableLayoutPanel1.Size = new Size(309, 54);
            tableLayoutPanel1.TabIndex = 49;
            // 
            // lbltableF3
            // 
            lbltableF3.Anchor = AnchorStyles.None;
            lbltableF3.AutoSize = true;
            lbltableF3.Font = new Font("標楷體", 14.25F);
            lbltableF3.Location = new Point(243, 17);
            lbltableF3.Name = "lbltableF3";
            lbltableF3.Size = new Size(29, 19);
            lbltableF3.TabIndex = 63;
            lbltableF3.Text = "F3";
            // 
            // lbltableF2
            // 
            lbltableF2.Anchor = AnchorStyles.None;
            lbltableF2.AutoSize = true;
            lbltableF2.Font = new Font("標楷體", 14.25F);
            lbltableF2.Location = new Point(142, 17);
            lbltableF2.Name = "lbltableF2";
            lbltableF2.Size = new Size(29, 19);
            lbltableF2.TabIndex = 62;
            lbltableF2.Text = "F2";
            // 
            // lbltableF1
            // 
            lbltableF1.Anchor = AnchorStyles.None;
            lbltableF1.AutoSize = true;
            lbltableF1.Font = new Font("標楷體", 14.25F);
            lbltableF1.Location = new Point(39, 17);
            lbltableF1.Name = "lbltableF1";
            lbltableF1.Size = new Size(29, 19);
            lbltableF1.TabIndex = 61;
            lbltableF1.Text = "F1";
            // 
            // lblFloor
            // 
            lblFloor.AutoSize = true;
            lblFloor.BackColor = Color.AntiqueWhite;
            lblFloor.Font = new Font("標楷體", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblFloor.Location = new Point(469, 116);
            lblFloor.Name = "lblFloor";
            lblFloor.Size = new Size(54, 21);
            lblFloor.TabIndex = 56;
            lblFloor.Text = "樓梯";
            // 
            // tableLayoutPanel2
            // 
            tableLayoutPanel2.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            tableLayoutPanel2.BackColor = Color.White;
            tableLayoutPanel2.CellBorderStyle = TableLayoutPanelCellBorderStyle.OutsetPartial;
            tableLayoutPanel2.ColumnCount = 1;
            tableLayoutPanel2.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel2.Controls.Add(lbltableG2, 0, 1);
            tableLayoutPanel2.Controls.Add(lbltableG1, 0, 0);
            tableLayoutPanel2.Location = new Point(85, 246);
            tableLayoutPanel2.Name = "tableLayoutPanel2";
            tableLayoutPanel2.RowCount = 2;
            tableLayoutPanel2.RowStyles.Add(new RowStyle(SizeType.Percent, 33.99F));
            tableLayoutPanel2.RowStyles.Add(new RowStyle(SizeType.Percent, 33.99F));
            tableLayoutPanel2.Size = new Size(54, 206);
            tableLayoutPanel2.TabIndex = 57;
            // 
            // lbltableG2
            // 
            lbltableG2.Anchor = AnchorStyles.None;
            lbltableG2.AutoSize = true;
            lbltableG2.Font = new Font("標楷體", 14.25F);
            lbltableG2.Location = new Point(12, 144);
            lbltableG2.Name = "lbltableG2";
            lbltableG2.Size = new Size(29, 19);
            lbltableG2.TabIndex = 64;
            lbltableG2.Text = "G2";
            // 
            // lbltableG1
            // 
            lbltableG1.Anchor = AnchorStyles.None;
            lbltableG1.AutoSize = true;
            lbltableG1.Font = new Font("標楷體", 14.25F);
            lbltableG1.Location = new Point(12, 42);
            lbltableG1.Name = "lbltableG1";
            lbltableG1.Size = new Size(29, 19);
            lbltableG1.TabIndex = 63;
            lbltableG1.Text = "G1";
            // 
            // tableLayoutPanel3
            // 
            tableLayoutPanel3.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            tableLayoutPanel3.BackColor = Color.White;
            tableLayoutPanel3.CellBorderStyle = TableLayoutPanelCellBorderStyle.OutsetPartial;
            tableLayoutPanel3.ColumnCount = 1;
            tableLayoutPanel3.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel3.Controls.Add(lbltableH2, 0, 1);
            tableLayoutPanel3.Controls.Add(lbltableH1, 0, 0);
            tableLayoutPanel3.Font = new Font("標楷體", 14.25F);
            tableLayoutPanel3.Location = new Point(228, 246);
            tableLayoutPanel3.Name = "tableLayoutPanel3";
            tableLayoutPanel3.RowCount = 2;
            tableLayoutPanel3.RowStyles.Add(new RowStyle(SizeType.Percent, 33.99F));
            tableLayoutPanel3.RowStyles.Add(new RowStyle(SizeType.Percent, 33.99F));
            tableLayoutPanel3.Size = new Size(54, 206);
            tableLayoutPanel3.TabIndex = 58;
            // 
            // lbltableH2
            // 
            lbltableH2.Anchor = AnchorStyles.None;
            lbltableH2.AutoSize = true;
            lbltableH2.Font = new Font("標楷體", 14.25F);
            lbltableH2.Location = new Point(12, 144);
            lbltableH2.Name = "lbltableH2";
            lbltableH2.Size = new Size(29, 19);
            lbltableH2.TabIndex = 64;
            lbltableH2.Text = "H2";
            // 
            // lbltableH1
            // 
            lbltableH1.Anchor = AnchorStyles.None;
            lbltableH1.AutoSize = true;
            lbltableH1.BackColor = Color.White;
            lbltableH1.Font = new Font("標楷體", 14.25F);
            lbltableH1.Location = new Point(12, 42);
            lbltableH1.Name = "lbltableH1";
            lbltableH1.Size = new Size(29, 19);
            lbltableH1.TabIndex = 63;
            lbltableH1.Text = "H1";
            // 
            // tableLayoutPanel4
            // 
            tableLayoutPanel4.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            tableLayoutPanel4.BackColor = Color.White;
            tableLayoutPanel4.CellBorderStyle = TableLayoutPanelCellBorderStyle.OutsetPartial;
            tableLayoutPanel4.ColumnCount = 1;
            tableLayoutPanel4.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel4.Controls.Add(lbltableI2, 0, 1);
            tableLayoutPanel4.Controls.Add(lbltableI1, 0, 0);
            tableLayoutPanel4.Location = new Point(371, 246);
            tableLayoutPanel4.Name = "tableLayoutPanel4";
            tableLayoutPanel4.RowCount = 2;
            tableLayoutPanel4.RowStyles.Add(new RowStyle(SizeType.Percent, 33.99F));
            tableLayoutPanel4.RowStyles.Add(new RowStyle(SizeType.Percent, 33.99F));
            tableLayoutPanel4.Size = new Size(54, 206);
            tableLayoutPanel4.TabIndex = 59;
            // 
            // lbltableI2
            // 
            lbltableI2.Anchor = AnchorStyles.None;
            lbltableI2.AutoSize = true;
            lbltableI2.Font = new Font("標楷體", 14.25F);
            lbltableI2.Location = new Point(12, 144);
            lbltableI2.Name = "lbltableI2";
            lbltableI2.Size = new Size(29, 19);
            lbltableI2.TabIndex = 64;
            lbltableI2.Text = "I2";
            // 
            // lbltableI1
            // 
            lbltableI1.Anchor = AnchorStyles.None;
            lbltableI1.AutoSize = true;
            lbltableI1.Font = new Font("標楷體", 14.25F);
            lbltableI1.Location = new Point(12, 42);
            lbltableI1.Name = "lbltableI1";
            lbltableI1.Size = new Size(29, 19);
            lbltableI1.TabIndex = 63;
            lbltableI1.Text = "I1";
            // 
            // tableLayoutPanel5
            // 
            tableLayoutPanel5.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            tableLayoutPanel5.BackColor = Color.White;
            tableLayoutPanel5.CellBorderStyle = TableLayoutPanelCellBorderStyle.OutsetPartial;
            tableLayoutPanel5.ColumnCount = 1;
            tableLayoutPanel5.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel5.Controls.Add(lbltableJ2, 0, 1);
            tableLayoutPanel5.Controls.Add(lbltableJ1, 0, 0);
            tableLayoutPanel5.Location = new Point(514, 246);
            tableLayoutPanel5.Name = "tableLayoutPanel5";
            tableLayoutPanel5.RowCount = 2;
            tableLayoutPanel5.RowStyles.Add(new RowStyle(SizeType.Percent, 33.99F));
            tableLayoutPanel5.RowStyles.Add(new RowStyle(SizeType.Percent, 33.99F));
            tableLayoutPanel5.Size = new Size(54, 206);
            tableLayoutPanel5.TabIndex = 60;
            // 
            // lbltableJ2
            // 
            lbltableJ2.Anchor = AnchorStyles.None;
            lbltableJ2.AutoSize = true;
            lbltableJ2.Font = new Font("標楷體", 14.25F);
            lbltableJ2.Location = new Point(12, 144);
            lbltableJ2.Name = "lbltableJ2";
            lbltableJ2.Size = new Size(29, 19);
            lbltableJ2.TabIndex = 64;
            lbltableJ2.Text = "J2";
            // 
            // lbltableJ1
            // 
            lbltableJ1.Anchor = AnchorStyles.None;
            lbltableJ1.AutoSize = true;
            lbltableJ1.Font = new Font("標楷體", 14.25F);
            lbltableJ1.Location = new Point(12, 42);
            lbltableJ1.Name = "lbltableJ1";
            lbltableJ1.Size = new Size(29, 19);
            lbltableJ1.TabIndex = 63;
            lbltableJ1.Text = "J1";
            // 
            // lblSeat
            // 
            lblSeat.AutoSize = true;
            lblSeat.Font = new Font("標楷體", 14.25F);
            lblSeat.Location = new Point(721, 116);
            lblSeat.Name = "lblSeat";
            lblSeat.Size = new Size(49, 19);
            lblSeat.TabIndex = 74;
            lblSeat.Text = "座位";
            // 
            // comboSeat
            // 
            comboSeat.BackColor = Color.White;
            comboSeat.DropDownHeight = 100;
            comboSeat.DropDownWidth = 5;
            comboSeat.Font = new Font("標楷體", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            comboSeat.FormattingEnabled = true;
            comboSeat.IntegralHeight = false;
            comboSeat.Items.AddRange(new object[] { "F1", "F2", "F3", "G1", "G2", "H1", "H3", "I1", "I2", "J1", "J2" });
            comboSeat.Location = new Point(721, 144);
            comboSeat.MaxDropDownItems = 5;
            comboSeat.MaxLength = 5;
            comboSeat.Name = "comboSeat";
            comboSeat.Size = new Size(200, 24);
            comboSeat.TabIndex = 73;
            comboSeat.SelectedIndexChanged += comboSeat_SelectedIndexChanged;
            // 
            // lblAfterNoon
            // 
            lblAfterNoon.AutoSize = true;
            lblAfterNoon.Font = new Font("標楷體", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblAfterNoon.Location = new Point(721, 420);
            lblAfterNoon.Name = "lblAfterNoon";
            lblAfterNoon.Size = new Size(89, 19);
            lblAfterNoon.TabIndex = 72;
            lblAfterNoon.Text = "下午時段";
            // 
            // lblMorning
            // 
            lblMorning.AutoSize = true;
            lblMorning.Font = new Font("標楷體", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblMorning.Location = new Point(721, 273);
            lblMorning.Name = "lblMorning";
            lblMorning.Size = new Size(89, 19);
            lblMorning.TabIndex = 71;
            lblMorning.Text = "上午時段";
            // 
            // checkTime8
            // 
            checkTime8.AutoSize = true;
            checkTime8.Font = new Font("標楷體", 14.25F);
            checkTime8.Location = new Point(875, 533);
            checkTime8.Name = "checkTime8";
            checkTime8.Size = new Size(138, 23);
            checkTime8.TabIndex = 70;
            checkTime8.Text = "15:00-16:00";
            checkTime8.UseVisualStyleBackColor = true;
            // 
            // checkTime7
            // 
            checkTime7.AutoSize = true;
            checkTime7.Font = new Font("標楷體", 14.25F);
            checkTime7.Location = new Point(721, 533);
            checkTime7.Name = "checkTime7";
            checkTime7.Size = new Size(138, 23);
            checkTime7.TabIndex = 69;
            checkTime7.Text = "14:00-15:00";
            checkTime7.UseVisualStyleBackColor = true;
            // 
            // checkTime6
            // 
            checkTime6.AutoSize = true;
            checkTime6.Font = new Font("標楷體", 14.25F);
            checkTime6.Location = new Point(875, 477);
            checkTime6.Name = "checkTime6";
            checkTime6.Size = new Size(138, 23);
            checkTime6.TabIndex = 68;
            checkTime6.Text = "13:00-14:00";
            checkTime6.UseVisualStyleBackColor = true;
            // 
            // checkTime5
            // 
            checkTime5.AutoSize = true;
            checkTime5.Font = new Font("標楷體", 14.25F);
            checkTime5.Location = new Point(721, 477);
            checkTime5.Name = "checkTime5";
            checkTime5.Size = new Size(138, 23);
            checkTime5.TabIndex = 67;
            checkTime5.Text = "12:00-13:00";
            checkTime5.UseVisualStyleBackColor = true;
            // 
            // checkTime4
            // 
            checkTime4.AutoSize = true;
            checkTime4.Font = new Font("標楷體", 14.25F);
            checkTime4.Location = new Point(865, 363);
            checkTime4.Name = "checkTime4";
            checkTime4.Size = new Size(138, 23);
            checkTime4.TabIndex = 66;
            checkTime4.Text = "11:00-12:00";
            checkTime4.UseVisualStyleBackColor = true;
            // 
            // checkTime3
            // 
            checkTime3.AutoSize = true;
            checkTime3.Font = new Font("標楷體", 14.25F);
            checkTime3.Location = new Point(721, 362);
            checkTime3.Name = "checkTime3";
            checkTime3.Size = new Size(138, 23);
            checkTime3.TabIndex = 65;
            checkTime3.Text = "10:00-11:00";
            checkTime3.UseVisualStyleBackColor = true;
            // 
            // checkTime2
            // 
            checkTime2.AutoSize = true;
            checkTime2.Font = new Font("標楷體", 14.25F);
            checkTime2.Location = new Point(865, 308);
            checkTime2.Name = "checkTime2";
            checkTime2.Size = new Size(138, 23);
            checkTime2.TabIndex = 64;
            checkTime2.Text = "09:00-10:00";
            checkTime2.UseVisualStyleBackColor = true;
            // 
            // checkTime1
            // 
            checkTime1.AutoSize = true;
            checkTime1.Font = new Font("標楷體", 14.25F);
            checkTime1.Location = new Point(721, 308);
            checkTime1.Name = "checkTime1";
            checkTime1.Size = new Size(138, 23);
            checkTime1.TabIndex = 63;
            checkTime1.Text = "08:00-09:00";
            checkTime1.UseVisualStyleBackColor = true;
            // 
            // lblDate
            // 
            lblDate.AutoSize = true;
            lblDate.Font = new Font("標楷體", 14.25F);
            lblDate.Location = new Point(721, 177);
            lblDate.Name = "lblDate";
            lblDate.Size = new Size(49, 19);
            lblDate.TabIndex = 62;
            lblDate.Text = "日期";
            // 
            // date
            // 
            date.CalendarForeColor = SystemColors.ActiveCaptionText;
            date.CalendarMonthBackground = SystemColors.Menu;
            date.Font = new Font("標楷體", 14.25F);
            date.Location = new Point(721, 205);
            date.MinDate = DateTime.Now;
            date.Name = "date";
            date.Size = new Size(200, 30);
            date.TabIndex = 61;
            date.Value = DateTime.Now;
            date.ValueChanged += date_ValueChanged;
            // 
            // SecondF
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.AntiqueWhite;
            ClientSize = new Size(1157, 665);
            Controls.Add(lblSeat);
            Controls.Add(comboSeat);
            Controls.Add(lblAfterNoon);
            Controls.Add(lblMorning);
            Controls.Add(checkTime8);
            Controls.Add(checkTime7);
            Controls.Add(checkTime6);
            Controls.Add(checkTime5);
            Controls.Add(checkTime4);
            Controls.Add(checkTime3);
            Controls.Add(checkTime2);
            Controls.Add(checkTime1);
            Controls.Add(lblDate);
            Controls.Add(date);
            Controls.Add(tableLayoutPanel5);
            Controls.Add(tableLayoutPanel4);
            Controls.Add(tableLayoutPanel3);
            Controls.Add(tableLayoutPanel2);
            Controls.Add(lblFloor);
            Controls.Add(tableLayoutPanel1);
            Controls.Add(btnNext);
            Controls.Add(lblChineseTitle);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "SecondF";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "小歇一刻K書中心 - 座位預約 - 二樓";
            FormClosed += SecondF_FormClosed;
            Click += SecondF_Click;
            tableLayoutPanel1.ResumeLayout(false);
            tableLayoutPanel1.PerformLayout();
            tableLayoutPanel2.ResumeLayout(false);
            tableLayoutPanel2.PerformLayout();
            tableLayoutPanel3.ResumeLayout(false);
            tableLayoutPanel3.PerformLayout();
            tableLayoutPanel4.ResumeLayout(false);
            tableLayoutPanel4.PerformLayout();
            tableLayoutPanel5.ResumeLayout(false);
            tableLayoutPanel5.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblChineseTitle;
        private Button btnNext;
        private TableLayoutPanel tableLayoutPanel1;
        private Label lblFloor;
        private TableLayoutPanel tableLayoutPanel2;
        private TableLayoutPanel tableLayoutPanel3;
        private TableLayoutPanel tableLayoutPanel4;
        private TableLayoutPanel tableLayoutPanel5;
        private Label lbltableF3;
        private Label lbltableF2;
        private Label lbltableF1;
        private Label lbltableG2;
        private Label lbltableG1;
        private Label lbltableH2;
        private Label lbltableH1;
        private Label lbltableI2;
        private Label lbltableI1;
        private Label lbltableJ2;
        private Label lbltableJ1;
        private Label lblSeat;
        private ComboBox comboSeat;
        private Label lblAfterNoon;
        private Label lblMorning;
        private CheckBox checkTime8;
        private CheckBox checkTime7;
        private CheckBox checkTime6;
        private CheckBox checkTime5;
        private CheckBox checkTime4;
        private CheckBox checkTime3;
        private CheckBox checkTime2;
        private CheckBox checkTime1;
        private Label lblDate;
        private DateTimePicker date;
    }
}