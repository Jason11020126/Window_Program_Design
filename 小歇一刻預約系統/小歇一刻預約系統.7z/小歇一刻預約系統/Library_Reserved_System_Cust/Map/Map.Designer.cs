﻿namespace Library_Reserved_System_Cust
{
    partial class Map
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Map));
            webMap = new Microsoft.Web.WebView2.WinForms.WebView2();
            ((System.ComponentModel.ISupportInitialize)webMap).BeginInit();
            SuspendLayout();
            // 
            // webMap
            // 
            webMap.AllowExternalDrop = true;
            webMap.CreationProperties = null;
            webMap.DefaultBackgroundColor = Color.White;
            webMap.Location = new Point(0, 0);
            webMap.Name = "webMap";
            webMap.Size = new Size(1157, 665);
            webMap.TabIndex = 0;
            webMap.ZoomFactor = 1D;
            // 
            // Map
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1157, 665);
            Controls.Add(webMap);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "Map";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "小歇一刻K書中心- 位置資訊";
            FormClosed += Map_FormClosed;
            Load += Map_Load;
            ((System.ComponentModel.ISupportInitialize)webMap).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Microsoft.Web.WebView2.WinForms.WebView2 webMap;
    }
}