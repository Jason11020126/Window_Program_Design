﻿namespace Library_Reserved_System_Cust
{
    partial class Login
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Login));
            lblEnglishTitle = new Label();
            panEnglishTitle = new Panel();
            lblChineseTitle = new Label();
            panLogin = new Panel();
            panGmail = new Panel();
            txtGmail = new TextBox();
            lblGmail = new Label();
            comboFloor = new ComboBox();
            lblFloor = new Label();
            lblNamePhone = new Label();
            lblCaptNotice = new Label();
            panCapt = new Panel();
            txtCapt = new TextBox();
            panPhone = new Panel();
            txtPhone = new TextBox();
            lblCaptcha = new Label();
            lblCaptchaTitle = new Label();
            pictureCapt = new PictureBox();
            lblPhone = new Label();
            panName = new Panel();
            txtName = new TextBox();
            lblName = new Label();
            btnNext = new Button();
            lblMaunal = new Label();
            timerTitle = new System.Windows.Forms.Timer(components);
            lblInfo = new Label();
            lblNotice = new Label();
            linkMap = new LinkLabel();
            panEnglishTitle.SuspendLayout();
            panLogin.SuspendLayout();
            panGmail.SuspendLayout();
            panCapt.SuspendLayout();
            panPhone.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureCapt).BeginInit();
            panName.SuspendLayout();
            SuspendLayout();
            // 
            // lblEnglishTitle
            // 
            lblEnglishTitle.Font = new Font("標楷體", 20.25F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            lblEnglishTitle.ForeColor = Color.Cyan;
            lblEnglishTitle.Location = new Point(615, 8);
            lblEnglishTitle.Name = "lblEnglishTitle";
            lblEnglishTitle.Size = new Size(750, 27);
            lblEnglishTitle.TabIndex = 0;
            lblEnglishTitle.Text = "Welcome to use this reading room reservation system";
            // 
            // panEnglishTitle
            // 
            panEnglishTitle.BackgroundImageLayout = ImageLayout.None;
            panEnglishTitle.Controls.Add(lblEnglishTitle);
            panEnglishTitle.Font = new Font("標楷體", 20F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 136);
            panEnglishTitle.ForeColor = Color.White;
            panEnglishTitle.Location = new Point(290, 39);
            panEnglishTitle.Name = "panEnglishTitle";
            panEnglishTitle.Size = new Size(715, 42);
            panEnglishTitle.TabIndex = 2;
            // 
            // lblChineseTitle
            // 
            lblChineseTitle.AutoSize = true;
            lblChineseTitle.Font = new Font("標楷體", 20.25F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            lblChineseTitle.ForeColor = Color.Red;
            lblChineseTitle.Location = new Point(357, 9);
            lblChineseTitle.Name = "lblChineseTitle";
            lblChineseTitle.Size = new Size(463, 27);
            lblChineseTitle.TabIndex = 3;
            lblChineseTitle.Text = "小歇一刻K書中心- 讀書室預約系統";
            // 
            // panLogin
            // 
            panLogin.BackColor = Color.AntiqueWhite;
            panLogin.Controls.Add(panGmail);
            panLogin.Controls.Add(lblGmail);
            panLogin.Controls.Add(comboFloor);
            panLogin.Controls.Add(lblFloor);
            panLogin.Controls.Add(lblNamePhone);
            panLogin.Controls.Add(lblCaptNotice);
            panLogin.Controls.Add(panCapt);
            panLogin.Controls.Add(panPhone);
            panLogin.Controls.Add(lblCaptcha);
            panLogin.Controls.Add(lblCaptchaTitle);
            panLogin.Controls.Add(pictureCapt);
            panLogin.Controls.Add(lblPhone);
            panLogin.Controls.Add(panName);
            panLogin.Controls.Add(lblName);
            panLogin.Location = new Point(30, 87);
            panLogin.Name = "panLogin";
            panLogin.Size = new Size(459, 556);
            panLogin.TabIndex = 4;
            // 
            // panGmail
            // 
            panGmail.BackColor = Color.FromArgb(100, 255, 255);
            panGmail.Controls.Add(txtGmail);
            panGmail.Font = new Font("標楷體", 15.75F);
            panGmail.Location = new Point(150, 167);
            panGmail.Name = "panGmail";
            panGmail.Size = new Size(275, 28);
            panGmail.TabIndex = 7;
            // 
            // txtGmail
            // 
            txtGmail.BackColor = Color.FromArgb(192, 255, 255);
            txtGmail.BorderStyle = BorderStyle.None;
            txtGmail.Font = new Font("標楷體", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtGmail.Location = new Point(4, 3);
            txtGmail.Multiline = true;
            txtGmail.Name = "txtGmail";
            txtGmail.PlaceholderText = "kstudy@gmail.com";
            txtGmail.Size = new Size(267, 22);
            txtGmail.TabIndex = 1;
            txtGmail.TabStop = false;
            // 
            // lblGmail
            // 
            lblGmail.AutoSize = true;
            lblGmail.Font = new Font("標楷體", 14.25F);
            lblGmail.Location = new Point(35, 172);
            lblGmail.Name = "lblGmail";
            lblGmail.Size = new Size(109, 19);
            lblGmail.TabIndex = 6;
            lblGmail.Text = "電子郵件: ";
            // 
            // comboFloor
            // 
            comboFloor.BackColor = Color.FromArgb(192, 255, 255);
            comboFloor.Font = new Font("標楷體", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            comboFloor.FormattingEnabled = true;
            comboFloor.Items.AddRange(new object[] { "一樓", "二樓" });
            comboFloor.Location = new Point(41, 268);
            comboFloor.Name = "comboFloor";
            comboFloor.Size = new Size(254, 27);
            comboFloor.TabIndex = 18;
            comboFloor.TabStop = false;
            // 
            // lblFloor
            // 
            lblFloor.Font = new Font("標楷體", 16F, FontStyle.Bold | FontStyle.Underline, GraphicsUnit.Point, 136);
            lblFloor.ForeColor = Color.FromArgb(0, 192, 192);
            lblFloor.Location = new Point(31, 225);
            lblFloor.Name = "lblFloor";
            lblFloor.Size = new Size(354, 23);
            lblFloor.TabIndex = 17;
            lblFloor.Text = "請選擇樓層                  ";
            // 
            // lblNamePhone
            // 
            lblNamePhone.Font = new Font("標楷體", 16F, FontStyle.Bold | FontStyle.Underline, GraphicsUnit.Point, 136);
            lblNamePhone.ForeColor = Color.FromArgb(0, 192, 192);
            lblNamePhone.Location = new Point(31, 17);
            lblNamePhone.Name = "lblNamePhone";
            lblNamePhone.Size = new Size(354, 23);
            lblNamePhone.TabIndex = 16;
            lblNamePhone.Text = "請輸入預約者姓名及電話           ";
            // 
            // lblCaptNotice
            // 
            lblCaptNotice.AutoSize = true;
            lblCaptNotice.Font = new Font("標楷體", 12F, FontStyle.Bold, GraphicsUnit.Point, 136);
            lblCaptNotice.ForeColor = Color.Red;
            lblCaptNotice.Location = new Point(31, 495);
            lblCaptNotice.Margin = new Padding(2, 0, 2, 0);
            lblCaptNotice.Name = "lblCaptNotice";
            lblCaptNotice.Size = new Size(394, 32);
            lblCaptNotice.TabIndex = 15;
            lblCaptNotice.Text = "驗證碼看不清，請點擊圖片更新。\r\nClick on the picture to refresh the CAPTCHA";
            // 
            // panCapt
            // 
            panCapt.BackColor = Color.FromArgb(100, 255, 255);
            panCapt.Controls.Add(txtCapt);
            panCapt.Location = new Point(131, 383);
            panCapt.Name = "panCapt";
            panCapt.Size = new Size(193, 31);
            panCapt.TabIndex = 5;
            // 
            // txtCapt
            // 
            txtCapt.BackColor = Color.FromArgb(192, 255, 255);
            txtCapt.BorderStyle = BorderStyle.None;
            txtCapt.Font = new Font("標楷體", 18F, FontStyle.Regular, GraphicsUnit.Point, 136);
            txtCapt.Location = new Point(3, 4);
            txtCapt.Multiline = true;
            txtCapt.Name = "txtCapt";
            txtCapt.Size = new Size(187, 23);
            txtCapt.TabIndex = 0;
            txtCapt.TabStop = false;
            // 
            // panPhone
            // 
            panPhone.BackColor = Color.FromArgb(100, 255, 255);
            panPhone.Controls.Add(txtPhone);
            panPhone.Font = new Font("標楷體", 15.75F);
            panPhone.Location = new Point(150, 115);
            panPhone.Name = "panPhone";
            panPhone.Size = new Size(275, 28);
            panPhone.TabIndex = 5;
            // 
            // txtPhone
            // 
            txtPhone.BackColor = Color.FromArgb(192, 255, 255);
            txtPhone.BorderStyle = BorderStyle.None;
            txtPhone.Font = new Font("標楷體", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtPhone.Location = new Point(4, 3);
            txtPhone.MaxLength = 10;
            txtPhone.Multiline = true;
            txtPhone.Name = "txtPhone";
            txtPhone.PlaceholderText = "09xxxxxxxx";
            txtPhone.Size = new Size(267, 22);
            txtPhone.TabIndex = 1;
            txtPhone.TabStop = false;
            // 
            // lblCaptcha
            // 
            lblCaptcha.AutoSize = true;
            lblCaptcha.FlatStyle = FlatStyle.System;
            lblCaptcha.Font = new Font("標楷體", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblCaptcha.Location = new Point(45, 389);
            lblCaptcha.Name = "lblCaptcha";
            lblCaptcha.Size = new Size(89, 19);
            lblCaptcha.TabIndex = 12;
            lblCaptcha.Text = "驗證碼: ";
            // 
            // lblCaptchaTitle
            // 
            lblCaptchaTitle.Font = new Font("標楷體", 16F, FontStyle.Bold | FontStyle.Underline, GraphicsUnit.Point, 136);
            lblCaptchaTitle.ForeColor = Color.FromArgb(0, 192, 192);
            lblCaptchaTitle.Location = new Point(35, 343);
            lblCaptchaTitle.Name = "lblCaptchaTitle";
            lblCaptchaTitle.Size = new Size(350, 23);
            lblCaptchaTitle.TabIndex = 11;
            lblCaptchaTitle.Text = "請輸入驗證碼                ";
            // 
            // pictureCapt
            // 
            pictureCapt.BackColor = Color.Silver;
            pictureCapt.Location = new Point(45, 437);
            pictureCapt.Name = "pictureCapt";
            pictureCapt.Size = new Size(136, 42);
            pictureCapt.TabIndex = 5;
            pictureCapt.TabStop = false;
            pictureCapt.Click += pictureCapt_Click;
            pictureCapt.Paint += pictureCapt_Paint;
            // 
            // lblPhone
            // 
            lblPhone.AutoSize = true;
            lblPhone.Font = new Font("標楷體", 14.25F);
            lblPhone.Location = new Point(35, 120);
            lblPhone.Name = "lblPhone";
            lblPhone.Size = new Size(69, 19);
            lblPhone.TabIndex = 1;
            lblPhone.Text = "電話: ";
            // 
            // panName
            // 
            panName.BackColor = Color.FromArgb(100, 255, 255);
            panName.Controls.Add(txtName);
            panName.Font = new Font("標楷體", 15.75F);
            panName.Location = new Point(150, 63);
            panName.Name = "panName";
            panName.Size = new Size(275, 28);
            panName.TabIndex = 14;
            // 
            // txtName
            // 
            txtName.BackColor = Color.FromArgb(192, 255, 255);
            txtName.BorderStyle = BorderStyle.None;
            txtName.Font = new Font("標楷體", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtName.Location = new Point(4, 3);
            txtName.Multiline = true;
            txtName.Name = "txtName";
            txtName.PlaceholderText = "王大明";
            txtName.Size = new Size(268, 22);
            txtName.TabIndex = 0;
            txtName.TabStop = false;
            // 
            // lblName
            // 
            lblName.AutoSize = true;
            lblName.Font = new Font("標楷體", 14.25F);
            lblName.Location = new Point(35, 68);
            lblName.Name = "lblName";
            lblName.Size = new Size(69, 19);
            lblName.TabIndex = 0;
            lblName.Text = "姓名: ";
            // 
            // btnNext
            // 
            btnNext.BackColor = Color.DeepSkyBlue;
            btnNext.FlatAppearance.BorderColor = Color.DeepSkyBlue;
            btnNext.FlatAppearance.BorderSize = 3;
            btnNext.FlatAppearance.MouseDownBackColor = Color.RoyalBlue;
            btnNext.FlatAppearance.MouseOverBackColor = Color.DodgerBlue;
            btnNext.FlatStyle = FlatStyle.Flat;
            btnNext.Font = new Font("標楷體", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnNext.ForeColor = Color.White;
            btnNext.Location = new Point(1023, 599);
            btnNext.Name = "btnNext";
            btnNext.Size = new Size(103, 44);
            btnNext.TabIndex = 13;
            btnNext.Text = "下一步";
            btnNext.UseVisualStyleBackColor = false;
            btnNext.Click += btnNext_Click;
            // 
            // lblMaunal
            // 
            lblMaunal.AutoSize = true;
            lblMaunal.Font = new Font("標楷體", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 136);
            lblMaunal.Location = new Point(579, 342);
            lblMaunal.Margin = new Padding(2, 0, 2, 0);
            lblMaunal.Name = "lblMaunal";
            lblMaunal.Size = new Size(0, 19);
            lblMaunal.TabIndex = 5;
            // 
            // timerTitle
            // 
            timerTitle.Enabled = true;
            timerTitle.Interval = 40;
            timerTitle.Tick += timerTitle_Tick;
            // 
            // lblInfo
            // 
            lblInfo.AutoSize = true;
            lblInfo.Font = new Font("標楷體", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 136);
            lblInfo.Location = new Point(579, 96);
            lblInfo.Margin = new Padding(2, 0, 2, 0);
            lblInfo.Name = "lblInfo";
            lblInfo.Size = new Size(0, 19);
            lblInfo.TabIndex = 14;
            // 
            // lblNotice
            // 
            lblNotice.AutoSize = true;
            lblNotice.Font = new Font("標楷體", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 136);
            lblNotice.Location = new Point(579, 219);
            lblNotice.Margin = new Padding(2, 0, 2, 0);
            lblNotice.Name = "lblNotice";
            lblNotice.Size = new Size(0, 19);
            lblNotice.TabIndex = 15;
            // 
            // linkMap
            // 
            linkMap.AutoSize = true;
            linkMap.Font = new Font("標楷體", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            linkMap.LinkBehavior = LinkBehavior.HoverUnderline;
            linkMap.LinkColor = SystemColors.HotTrack;
            linkMap.LiveSetting = System.Windows.Forms.Automation.AutomationLiveSetting.Polite;
            linkMap.Location = new Point(803, 131);
            linkMap.Name = "linkMap";
            linkMap.Size = new Size(89, 19);
            linkMap.TabIndex = 17;
            linkMap.TabStop = true;
            linkMap.Text = "查看地圖";
            linkMap.LinkClicked += linkMap_LinkClicked;
            // 
            // Login
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.AntiqueWhite;
            ClientSize = new Size(1157, 665);
            Controls.Add(linkMap);
            Controls.Add(lblNotice);
            Controls.Add(lblInfo);
            Controls.Add(lblMaunal);
            Controls.Add(panLogin);
            Controls.Add(lblChineseTitle);
            Controls.Add(panEnglishTitle);
            Controls.Add(btnNext);
            DoubleBuffered = true;
            Icon = (Icon)resources.GetObject("$this.Icon");
            Location = new Point(50, 50);
            Name = "Login";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "小歇一刻K書中心- 讀書室預約系統";
            TransparencyKey = Color.FromArgb(224, 224, 224);
            FormClosed += Login_FormClosed;
            Click += Login_Click;
            panEnglishTitle.ResumeLayout(false);
            panLogin.ResumeLayout(false);
            panLogin.PerformLayout();
            panGmail.ResumeLayout(false);
            panGmail.PerformLayout();
            panCapt.ResumeLayout(false);
            panCapt.PerformLayout();
            panPhone.ResumeLayout(false);
            panPhone.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureCapt).EndInit();
            panName.ResumeLayout(false);
            panName.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Label lblEnglishTitle;
        private Panel panEnglishTitle;
        private Label lblChineseTitle;
        private Panel panLogin;
        private Label lblPhone;
        private TextBox txtCapt;
        private Label lblCaptcha;
        private Label lblCaptchaTitle;
        private Button btnNext;
        private Panel panName;
        private TextBox txtName;
        private Label lblName;
        private Panel panPhone;
        private Panel panCapt;
        private PictureBox pictureCapt;
        private Label lblCaptNotice;
        private Label lblMaunal;
        private TextBox txtPhone;
        private Label lblNamePhone;
        private Label lblFloor;
        private ComboBox comboFloor;
        private Panel panGmail;
        private TextBox txtGmail;
        private Label lblGmail;
        private System.Windows.Forms.Timer timerTitle;
        private Label lblInfo;
        private Label lblNotice;
        private LinkLabel linkMap;
    }
}
