﻿namespace Library_Reserved_System_Cust
{
    partial class FirstF
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FirstF));
            lblChineseTitle = new Label();
            btnNext = new Button();
            tableB = new TableLayoutPanel();
            lbltableB4 = new Label();
            lbltableB3 = new Label();
            lbltableB2 = new Label();
            lbltableB1 = new Label();
            tableA = new TableLayoutPanel();
            lbltableA5 = new Label();
            lbltableA4 = new Label();
            lbltableA3 = new Label();
            lbltableA2 = new Label();
            lbltableA1 = new Label();
            lblEntrance = new Label();
            tableC = new TableLayoutPanel();
            lbltableC6 = new Label();
            lbltableC5 = new Label();
            lbltableC4 = new Label();
            lbltableC2 = new Label();
            lbltableC1 = new Label();
            tableD = new TableLayoutPanel();
            lbltableD5 = new Label();
            lbltableD4 = new Label();
            lbltableD3 = new Label();
            lbltableD2 = new Label();
            lbltableD1 = new Label();
            tableE = new TableLayoutPanel();
            lbltableE5 = new Label();
            lbltableE4 = new Label();
            lbltableE3 = new Label();
            lbltableE2 = new Label();
            lbltableE1 = new Label();
            lblFloor = new Label();
            date = new DateTimePicker();
            lblDate = new Label();
            checkTime1 = new CheckBox();
            checkTime2 = new CheckBox();
            checkTime3 = new CheckBox();
            checkTime4 = new CheckBox();
            checkTime5 = new CheckBox();
            checkTime6 = new CheckBox();
            checkTime7 = new CheckBox();
            checkTime8 = new CheckBox();
            lblMorning = new Label();
            lblAfterNoon = new Label();
            comboSeat = new ComboBox();
            lblSeat = new Label();
            tableB.SuspendLayout();
            tableA.SuspendLayout();
            tableC.SuspendLayout();
            tableD.SuspendLayout();
            tableE.SuspendLayout();
            SuspendLayout();
            // 
            // lblChineseTitle
            // 
            lblChineseTitle.AutoSize = true;
            lblChineseTitle.Font = new Font("標楷體", 20.25F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            lblChineseTitle.ForeColor = Color.Red;
            lblChineseTitle.Location = new Point(371, 19);
            lblChineseTitle.Name = "lblChineseTitle";
            lblChineseTitle.Size = new Size(463, 27);
            lblChineseTitle.TabIndex = 5;
            lblChineseTitle.Text = "小歇一刻K書中心- 讀書室預約系統";
            // 
            // btnNext
            // 
            btnNext.BackColor = Color.DeepSkyBlue;
            btnNext.FlatAppearance.BorderColor = Color.DeepSkyBlue;
            btnNext.FlatAppearance.BorderSize = 3;
            btnNext.FlatAppearance.MouseDownBackColor = Color.RoyalBlue;
            btnNext.FlatAppearance.MouseOverBackColor = Color.DodgerBlue;
            btnNext.FlatStyle = FlatStyle.Flat;
            btnNext.Font = new Font("標楷體", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnNext.ForeColor = Color.White;
            btnNext.Location = new Point(1023, 599);
            btnNext.Name = "btnNext";
            btnNext.Size = new Size(103, 44);
            btnNext.TabIndex = 14;
            btnNext.Text = "下一步";
            btnNext.UseVisualStyleBackColor = false;
            btnNext.Click += btnNext_Click;
            // 
            // tableB
            // 
            tableB.BackColor = Color.White;
            tableB.CellBorderStyle = TableLayoutPanelCellBorderStyle.OutsetPartial;
            tableB.ColumnCount = 1;
            tableB.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableB.Controls.Add(lbltableB4, 0, 3);
            tableB.Controls.Add(lbltableB3, 0, 2);
            tableB.Controls.Add(lbltableB2, 0, 1);
            tableB.Controls.Add(lbltableB1, 0, 0);
            tableB.Location = new Point(92, 215);
            tableB.Name = "tableB";
            tableB.RowCount = 4;
            tableB.RowStyles.Add(new RowStyle(SizeType.Percent, 20F));
            tableB.RowStyles.Add(new RowStyle(SizeType.Percent, 20F));
            tableB.RowStyles.Add(new RowStyle(SizeType.Percent, 20F));
            tableB.RowStyles.Add(new RowStyle(SizeType.Percent, 20F));
            tableB.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tableB.Size = new Size(55, 230);
            tableB.TabIndex = 16;
            // 
            // lbltableB4
            // 
            lbltableB4.Anchor = AnchorStyles.None;
            lbltableB4.Font = new Font("標楷體", 12F);
            lbltableB4.Location = new Point(6, 171);
            lbltableB4.Name = "lbltableB4";
            lbltableB4.Size = new Size(43, 56);
            lbltableB4.TabIndex = 27;
            lbltableB4.Text = "B4";
            lbltableB4.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // lbltableB3
            // 
            lbltableB3.Anchor = AnchorStyles.None;
            lbltableB3.Font = new Font("標楷體", 12F);
            lbltableB3.Location = new Point(6, 115);
            lbltableB3.Name = "lbltableB3";
            lbltableB3.Size = new Size(43, 53);
            lbltableB3.TabIndex = 26;
            lbltableB3.Text = "B3";
            lbltableB3.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // lbltableB2
            // 
            lbltableB2.Anchor = AnchorStyles.None;
            lbltableB2.Font = new Font("標楷體", 12F);
            lbltableB2.Location = new Point(6, 59);
            lbltableB2.Name = "lbltableB2";
            lbltableB2.Size = new Size(43, 53);
            lbltableB2.TabIndex = 25;
            lbltableB2.Text = "B2";
            lbltableB2.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // lbltableB1
            // 
            lbltableB1.Anchor = AnchorStyles.None;
            lbltableB1.Font = new Font("標楷體", 12F);
            lbltableB1.Location = new Point(6, 3);
            lbltableB1.Name = "lbltableB1";
            lbltableB1.Size = new Size(43, 53);
            lbltableB1.TabIndex = 24;
            lbltableB1.Text = "B1";
            lbltableB1.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // tableA
            // 
            tableA.BackColor = Color.White;
            tableA.CellBorderStyle = TableLayoutPanelCellBorderStyle.OutsetPartial;
            tableA.ColumnCount = 5;
            tableA.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20F));
            tableA.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20F));
            tableA.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20F));
            tableA.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20F));
            tableA.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20F));
            tableA.Controls.Add(lbltableA5, 4, 0);
            tableA.Controls.Add(lbltableA4, 3, 0);
            tableA.Controls.Add(lbltableA3, 2, 0);
            tableA.Controls.Add(lbltableA2, 1, 0);
            tableA.Controls.Add(lbltableA1, 0, 0);
            tableA.Location = new Point(92, 116);
            tableA.Name = "tableA";
            tableA.RowCount = 1;
            tableA.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            tableA.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tableA.Size = new Size(263, 54);
            tableA.TabIndex = 17;
            // 
            // lbltableA5
            // 
            lbltableA5.Anchor = AnchorStyles.None;
            lbltableA5.BackColor = Color.White;
            lbltableA5.Font = new Font("標楷體", 12F);
            lbltableA5.Location = new Point(214, 3);
            lbltableA5.Name = "lbltableA5";
            lbltableA5.Size = new Size(43, 48);
            lbltableA5.TabIndex = 27;
            lbltableA5.Text = "A5";
            lbltableA5.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // lbltableA4
            // 
            lbltableA4.Anchor = AnchorStyles.None;
            lbltableA4.Font = new Font("標楷體", 12F);
            lbltableA4.Location = new Point(162, 3);
            lbltableA4.Name = "lbltableA4";
            lbltableA4.Size = new Size(43, 48);
            lbltableA4.TabIndex = 26;
            lbltableA4.Text = "A4";
            lbltableA4.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // lbltableA3
            // 
            lbltableA3.Anchor = AnchorStyles.None;
            lbltableA3.Font = new Font("標楷體", 12F);
            lbltableA3.Location = new Point(110, 3);
            lbltableA3.Name = "lbltableA3";
            lbltableA3.Size = new Size(43, 48);
            lbltableA3.TabIndex = 25;
            lbltableA3.Text = "A3";
            lbltableA3.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // lbltableA2
            // 
            lbltableA2.Anchor = AnchorStyles.None;
            lbltableA2.Font = new Font("標楷體", 12F);
            lbltableA2.Location = new Point(58, 3);
            lbltableA2.Name = "lbltableA2";
            lbltableA2.Size = new Size(43, 48);
            lbltableA2.TabIndex = 24;
            lbltableA2.Text = "A2";
            lbltableA2.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // lbltableA1
            // 
            lbltableA1.Anchor = AnchorStyles.None;
            lbltableA1.Font = new Font("標楷體", 12F);
            lbltableA1.Location = new Point(6, 3);
            lbltableA1.Name = "lbltableA1";
            lbltableA1.Size = new Size(43, 48);
            lbltableA1.TabIndex = 23;
            lbltableA1.Text = "A1";
            lbltableA1.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // lblEntrance
            // 
            lblEntrance.AutoSize = true;
            lblEntrance.BackColor = Color.AntiqueWhite;
            lblEntrance.Font = new Font("標楷體", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblEntrance.Location = new Point(191, 475);
            lblEntrance.Name = "lblEntrance";
            lblEntrance.Size = new Size(54, 21);
            lblEntrance.TabIndex = 18;
            lblEntrance.Text = "門口";
            // 
            // tableC
            // 
            tableC.BackColor = Color.White;
            tableC.CellBorderStyle = TableLayoutPanelCellBorderStyle.OutsetPartial;
            tableC.ColumnCount = 5;
            tableC.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20F));
            tableC.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20F));
            tableC.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20F));
            tableC.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20F));
            tableC.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20F));
            tableC.Controls.Add(lbltableC6, 4, 0);
            tableC.Controls.Add(lbltableC5, 3, 0);
            tableC.Controls.Add(lbltableC4, 2, 0);
            tableC.Controls.Add(lbltableC2, 1, 0);
            tableC.Controls.Add(lbltableC1, 0, 0);
            tableC.Location = new Point(202, 215);
            tableC.Name = "tableC";
            tableC.RowCount = 1;
            tableC.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            tableC.Size = new Size(263, 54);
            tableC.TabIndex = 19;
            // 
            // lbltableC6
            // 
            lbltableC6.Anchor = AnchorStyles.None;
            lbltableC6.Font = new Font("標楷體", 12F);
            lbltableC6.Location = new Point(214, 3);
            lbltableC6.Name = "lbltableC6";
            lbltableC6.Size = new Size(43, 48);
            lbltableC6.TabIndex = 29;
            lbltableC6.Text = "C5";
            lbltableC6.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // lbltableC5
            // 
            lbltableC5.Anchor = AnchorStyles.None;
            lbltableC5.Font = new Font("標楷體", 12F);
            lbltableC5.Location = new Point(162, 3);
            lbltableC5.Name = "lbltableC5";
            lbltableC5.Size = new Size(43, 48);
            lbltableC5.TabIndex = 28;
            lbltableC5.Text = "C4";
            lbltableC5.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // lbltableC4
            // 
            lbltableC4.Anchor = AnchorStyles.None;
            lbltableC4.Font = new Font("標楷體", 12F);
            lbltableC4.Location = new Point(110, 3);
            lbltableC4.Name = "lbltableC4";
            lbltableC4.Size = new Size(43, 48);
            lbltableC4.TabIndex = 27;
            lbltableC4.Text = "C3";
            lbltableC4.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // lbltableC2
            // 
            lbltableC2.Anchor = AnchorStyles.None;
            lbltableC2.Font = new Font("標楷體", 12F);
            lbltableC2.Location = new Point(58, 3);
            lbltableC2.Name = "lbltableC2";
            lbltableC2.Size = new Size(43, 48);
            lbltableC2.TabIndex = 26;
            lbltableC2.Text = "C2";
            lbltableC2.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // lbltableC1
            // 
            lbltableC1.Anchor = AnchorStyles.None;
            lbltableC1.Font = new Font("標楷體", 12F);
            lbltableC1.Location = new Point(6, 3);
            lbltableC1.Name = "lbltableC1";
            lbltableC1.Size = new Size(43, 48);
            lbltableC1.TabIndex = 25;
            lbltableC1.Text = "C1";
            lbltableC1.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // tableD
            // 
            tableD.BackColor = Color.White;
            tableD.CellBorderStyle = TableLayoutPanelCellBorderStyle.OutsetPartial;
            tableD.ColumnCount = 5;
            tableD.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20F));
            tableD.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20F));
            tableD.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20F));
            tableD.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20F));
            tableD.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20F));
            tableD.Controls.Add(lbltableD5, 4, 0);
            tableD.Controls.Add(lbltableD4, 3, 0);
            tableD.Controls.Add(lbltableD3, 2, 0);
            tableD.Controls.Add(lbltableD2, 1, 0);
            tableD.Controls.Add(lbltableD1, 0, 0);
            tableD.Location = new Point(202, 306);
            tableD.Name = "tableD";
            tableD.RowCount = 1;
            tableD.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            tableD.Size = new Size(263, 54);
            tableD.TabIndex = 20;
            // 
            // lbltableD5
            // 
            lbltableD5.Anchor = AnchorStyles.None;
            lbltableD5.Font = new Font("標楷體", 12F);
            lbltableD5.Location = new Point(214, 3);
            lbltableD5.Name = "lbltableD5";
            lbltableD5.Size = new Size(43, 48);
            lbltableD5.TabIndex = 30;
            lbltableD5.Text = "D5";
            lbltableD5.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // lbltableD4
            // 
            lbltableD4.Anchor = AnchorStyles.None;
            lbltableD4.Font = new Font("標楷體", 12F);
            lbltableD4.Location = new Point(162, 3);
            lbltableD4.Name = "lbltableD4";
            lbltableD4.Size = new Size(43, 48);
            lbltableD4.TabIndex = 29;
            lbltableD4.Text = "D4";
            lbltableD4.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // lbltableD3
            // 
            lbltableD3.Anchor = AnchorStyles.None;
            lbltableD3.Font = new Font("標楷體", 12F);
            lbltableD3.Location = new Point(110, 3);
            lbltableD3.Name = "lbltableD3";
            lbltableD3.Size = new Size(43, 48);
            lbltableD3.TabIndex = 28;
            lbltableD3.Text = "D3";
            lbltableD3.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // lbltableD2
            // 
            lbltableD2.Anchor = AnchorStyles.None;
            lbltableD2.Font = new Font("標楷體", 12F);
            lbltableD2.Location = new Point(58, 3);
            lbltableD2.Name = "lbltableD2";
            lbltableD2.Size = new Size(43, 48);
            lbltableD2.TabIndex = 27;
            lbltableD2.Text = "D2";
            lbltableD2.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // lbltableD1
            // 
            lbltableD1.Anchor = AnchorStyles.None;
            lbltableD1.Font = new Font("標楷體", 12F);
            lbltableD1.Location = new Point(6, 3);
            lbltableD1.Name = "lbltableD1";
            lbltableD1.Size = new Size(43, 48);
            lbltableD1.TabIndex = 26;
            lbltableD1.Text = "D1";
            lbltableD1.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // tableE
            // 
            tableE.BackColor = Color.White;
            tableE.CellBorderStyle = TableLayoutPanelCellBorderStyle.OutsetPartial;
            tableE.ColumnCount = 1;
            tableE.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableE.Controls.Add(lbltableE5, 0, 4);
            tableE.Controls.Add(lbltableE4, 0, 3);
            tableE.Controls.Add(lbltableE3, 0, 2);
            tableE.Controls.Add(lbltableE2, 0, 1);
            tableE.Controls.Add(lbltableE1, 0, 0);
            tableE.Location = new Point(538, 158);
            tableE.Name = "tableE";
            tableE.RowCount = 5;
            tableE.RowStyles.Add(new RowStyle(SizeType.Percent, 20F));
            tableE.RowStyles.Add(new RowStyle(SizeType.Percent, 20F));
            tableE.RowStyles.Add(new RowStyle(SizeType.Percent, 20F));
            tableE.RowStyles.Add(new RowStyle(SizeType.Percent, 20F));
            tableE.RowStyles.Add(new RowStyle(SizeType.Percent, 20F));
            tableE.Size = new Size(55, 284);
            tableE.TabIndex = 21;
            // 
            // lbltableE5
            // 
            lbltableE5.Anchor = AnchorStyles.None;
            lbltableE5.Font = new Font("標楷體", 12F);
            lbltableE5.Location = new Point(6, 227);
            lbltableE5.Name = "lbltableE5";
            lbltableE5.Size = new Size(43, 54);
            lbltableE5.TabIndex = 30;
            lbltableE5.Text = "E5";
            lbltableE5.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // lbltableE4
            // 
            lbltableE4.Anchor = AnchorStyles.None;
            lbltableE4.Font = new Font("標楷體", 12F);
            lbltableE4.Location = new Point(6, 171);
            lbltableE4.Name = "lbltableE4";
            lbltableE4.Size = new Size(43, 53);
            lbltableE4.TabIndex = 29;
            lbltableE4.Text = "E4";
            lbltableE4.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // lbltableE3
            // 
            lbltableE3.Anchor = AnchorStyles.None;
            lbltableE3.Font = new Font("標楷體", 12F);
            lbltableE3.Location = new Point(6, 115);
            lbltableE3.Name = "lbltableE3";
            lbltableE3.Size = new Size(43, 53);
            lbltableE3.TabIndex = 28;
            lbltableE3.Text = "E3";
            lbltableE3.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // lbltableE2
            // 
            lbltableE2.Anchor = AnchorStyles.None;
            lbltableE2.Font = new Font("標楷體", 12F);
            lbltableE2.Location = new Point(6, 59);
            lbltableE2.Name = "lbltableE2";
            lbltableE2.Size = new Size(43, 53);
            lbltableE2.TabIndex = 27;
            lbltableE2.Text = "E2";
            lbltableE2.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // lbltableE1
            // 
            lbltableE1.Anchor = AnchorStyles.None;
            lbltableE1.Font = new Font("標楷體", 12F);
            lbltableE1.Location = new Point(6, 3);
            lbltableE1.Name = "lbltableE1";
            lbltableE1.Size = new Size(43, 53);
            lbltableE1.TabIndex = 26;
            lbltableE1.Text = "E1";
            lbltableE1.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // lblFloor
            // 
            lblFloor.AutoSize = true;
            lblFloor.BackColor = Color.AntiqueWhite;
            lblFloor.Font = new Font("標楷體", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblFloor.Location = new Point(469, 116);
            lblFloor.Name = "lblFloor";
            lblFloor.Size = new Size(54, 21);
            lblFloor.TabIndex = 22;
            lblFloor.Text = "樓梯";
            // 
            // date
            // 
            date.Font = new Font("標楷體", 14.25F);
            date.Location = new Point(721, 205);
            date.MinDate = DateTime.Now;
            date.Name = "date";
            date.Size = new Size(200, 30);
            date.TabIndex = 25;
            date.Value = DateTime.Now;
            date.ValueChanged += date_ValueChanged;
            // 
            // lblDate
            // 
            lblDate.AutoSize = true;
            lblDate.Font = new Font("標楷體", 14.25F);
            lblDate.Location = new Point(721, 177);
            lblDate.Name = "lblDate";
            lblDate.Size = new Size(49, 19);
            lblDate.TabIndex = 26;
            lblDate.Text = "日期";
            // 
            // checkTime1
            // 
            checkTime1.AutoSize = true;
            checkTime1.Font = new Font("標楷體", 14.25F);
            checkTime1.Location = new Point(721, 309);
            checkTime1.Name = "checkTime1";
            checkTime1.Size = new Size(138, 23);
            checkTime1.TabIndex = 27;
            checkTime1.Text = "08:00-09:00";
            checkTime1.UseVisualStyleBackColor = true;
            // 
            // checkTime2
            // 
            checkTime2.AutoSize = true;
            checkTime2.Font = new Font("標楷體", 14.25F);
            checkTime2.Location = new Point(865, 308);
            checkTime2.Name = "checkTime2";
            checkTime2.Size = new Size(138, 23);
            checkTime2.TabIndex = 28;
            checkTime2.Text = "09:00-10:00";
            checkTime2.UseVisualStyleBackColor = true;
            // 
            // checkTime3
            // 
            checkTime3.AutoSize = true;
            checkTime3.Font = new Font("標楷體", 14.25F);
            checkTime3.Location = new Point(721, 362);
            checkTime3.Name = "checkTime3";
            checkTime3.Size = new Size(138, 23);
            checkTime3.TabIndex = 29;
            checkTime3.Text = "10:00-11:00";
            checkTime3.UseVisualStyleBackColor = true;
            // 
            // checkTime4
            // 
            checkTime4.AutoSize = true;
            checkTime4.Font = new Font("標楷體", 14.25F);
            checkTime4.Location = new Point(865, 363);
            checkTime4.Name = "checkTime4";
            checkTime4.Size = new Size(138, 23);
            checkTime4.TabIndex = 30;
            checkTime4.Text = "11:00-12:00";
            checkTime4.UseVisualStyleBackColor = true;
            // 
            // checkTime5
            // 
            checkTime5.AutoSize = true;
            checkTime5.Font = new Font("標楷體", 14.25F);
            checkTime5.Location = new Point(721, 477);
            checkTime5.Name = "checkTime5";
            checkTime5.Size = new Size(138, 23);
            checkTime5.TabIndex = 31;
            checkTime5.Text = "12:00-13:00";
            checkTime5.UseVisualStyleBackColor = true;
            // 
            // checkTime6
            // 
            checkTime6.AutoSize = true;
            checkTime6.Font = new Font("標楷體", 14.25F);
            checkTime6.Location = new Point(875, 477);
            checkTime6.Name = "checkTime6";
            checkTime6.Size = new Size(138, 23);
            checkTime6.TabIndex = 32;
            checkTime6.Text = "13:00-14:00";
            checkTime6.UseVisualStyleBackColor = true;
            // 
            // checkTime7
            // 
            checkTime7.AutoSize = true;
            checkTime7.Font = new Font("標楷體", 14.25F);
            checkTime7.Location = new Point(721, 533);
            checkTime7.Name = "checkTime7";
            checkTime7.Size = new Size(138, 23);
            checkTime7.TabIndex = 33;
            checkTime7.Text = "14:00-15:00";
            checkTime7.UseVisualStyleBackColor = true;
            // 
            // checkTime8
            // 
            checkTime8.AutoSize = true;
            checkTime8.Font = new Font("標楷體", 14.25F);
            checkTime8.Location = new Point(875, 533);
            checkTime8.Name = "checkTime8";
            checkTime8.Size = new Size(138, 23);
            checkTime8.TabIndex = 34;
            checkTime8.Text = "15:00-16:00";
            checkTime8.UseVisualStyleBackColor = true;
            // 
            // lblMorning
            // 
            lblMorning.AutoSize = true;
            lblMorning.Font = new Font("標楷體", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblMorning.Location = new Point(721, 273);
            lblMorning.Name = "lblMorning";
            lblMorning.Size = new Size(89, 19);
            lblMorning.TabIndex = 35;
            lblMorning.Text = "上午時段";
            // 
            // lblAfterNoon
            // 
            lblAfterNoon.AutoSize = true;
            lblAfterNoon.Font = new Font("標楷體", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblAfterNoon.Location = new Point(721, 420);
            lblAfterNoon.Name = "lblAfterNoon";
            lblAfterNoon.Size = new Size(89, 19);
            lblAfterNoon.TabIndex = 36;
            lblAfterNoon.Text = "下午時段";
            // 
            // comboSeat
            // 
            comboSeat.DropDownHeight = 100;
            comboSeat.DropDownWidth = 5;
            comboSeat.Font = new Font("標楷體", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            comboSeat.FormattingEnabled = true;
            comboSeat.IntegralHeight = false;
            comboSeat.Items.AddRange(new object[] { "A1", "A2", "A3", "A4", "A5", "B1", "B2", "B3", "B4", "C1", "C2", "C3", "C4", "C5", "D1", "D2", "D3", "D4", "D5", "E1", "E2", "E3", "E4", "E5" });
            comboSeat.Location = new Point(721, 144);
            comboSeat.MaxDropDownItems = 5;
            comboSeat.MaxLength = 5;
            comboSeat.Name = "comboSeat";
            comboSeat.Size = new Size(200, 24);
            comboSeat.TabIndex = 37;
            comboSeat.SelectedIndexChanged += comboSeat_SelectedIndexChanged;
            // 
            // lblSeat
            // 
            lblSeat.AutoSize = true;
            lblSeat.Font = new Font("標楷體", 14.25F);
            lblSeat.Location = new Point(721, 116);
            lblSeat.Name = "lblSeat";
            lblSeat.Size = new Size(49, 19);
            lblSeat.TabIndex = 38;
            lblSeat.Text = "座位";
            // 
            // FirstF
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.AntiqueWhite;
            ClientSize = new Size(1157, 665);
            Controls.Add(lblSeat);
            Controls.Add(comboSeat);
            Controls.Add(lblAfterNoon);
            Controls.Add(lblMorning);
            Controls.Add(checkTime8);
            Controls.Add(checkTime7);
            Controls.Add(checkTime6);
            Controls.Add(checkTime5);
            Controls.Add(checkTime4);
            Controls.Add(checkTime3);
            Controls.Add(checkTime2);
            Controls.Add(checkTime1);
            Controls.Add(lblDate);
            Controls.Add(date);
            Controls.Add(lblFloor);
            Controls.Add(tableE);
            Controls.Add(tableD);
            Controls.Add(tableC);
            Controls.Add(lblEntrance);
            Controls.Add(tableA);
            Controls.Add(tableB);
            Controls.Add(btnNext);
            Controls.Add(lblChineseTitle);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "FirstF";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "小歇一刻K書中心 - 座位預約 - 一樓";
            FormClosed += FirstF_FormClosed;
            Click += FirstF_Click;
            tableB.ResumeLayout(false);
            tableA.ResumeLayout(false);
            tableC.ResumeLayout(false);
            tableD.ResumeLayout(false);
            tableE.ResumeLayout(false);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Label lblChineseTitle;
        private Button btnNext;
        private TableLayoutPanel tableB;
        private TableLayoutPanel tableA;
        private Label lblEntrance;
        private TableLayoutPanel tableC;
        private TableLayoutPanel tableD;
        private TableLayoutPanel tableE;
        private Label lblFloor;
        private Label lbltableA1;
        private Label lbltableB4;
        private Label lbltableB3;
        private Label lbltableB2;
        private Label lbltableB1;
        private Label lbltableA5;
        private Label lbltableA4;
        private Label lbltableA3;
        private Label lbltableA2;
        private Label lbltableC6;
        private Label lbltableC5;
        private Label lbltableC4;
        private Label lbltableC2;
        private Label lbltableC1;
        private Label lbltableD5;
        private Label lbltableD4;
        private Label lbltableD3;
        private Label lbltableD2;
        private Label lbltableD1;
        private Label lbltableE5;
        private Label lbltableE4;
        private Label lbltableE3;
        private Label lbltableE2;
        private Label lbltableE1;
        private DateTimePicker date;
        private Label lblDate;
        private CheckBox checkTime1;
        private CheckBox checkTime2;
        private CheckBox checkTime3;
        private CheckBox checkTime4;
        private CheckBox checkTime5;
        private CheckBox checkTime6;
        private CheckBox checkTime7;
        private CheckBox checkTime8;
        private Label lblMorning;
        private Label lblAfterNoon;
        private ComboBox comboSeat;
        private Label lblSeat;
    }
}