﻿namespace Library_Reserved_System_Cust
{
    public partial class Verify : Form
    {
        string captcha = "";
        byte RestedTime = 60;
        public Verify()
        {
            InitializeComponent();
            clearTxtFocus(this.Controls);
            SendEmail();
        }
        private void SendEmail()
        {
            Smtp smtp = new Smtp();
            generateCaptcha();
            smtp.buildVerifyHTML(captcha);
            smtp.sendVerifyGmail();
            OpenTimer();
        }
        private void OpenTimer()
        {
            btnAgainSend.Visible = false;
            lblVaildTime.Visible = true;
            timer1.Enabled = true;
        }
        private void CloseTimer()
        {
            btnAgainSend.Visible = true;
            lblVaildTime.Visible = false;
            timer1.Enabled = false;
        }
        private void clearTxtFocus(Control.ControlCollection Controls)
        {
            foreach (Control control in Controls)
            {
                // 避免綁到 TextBox 本身
                if (!(control is TextBox))
                {
                    control.Click += (s, e) =>
                    {
                        this.ActiveControl = null; // 清除焦點
                    };
                }

                // 如果有子控制項（例如 Panel 裡面的 Button）
                if (control.HasChildren)
                    clearTxtFocus(control.Controls);
            }
            //form自身也要加上
            this.Click += (s, e) => { this.ActiveControl = null; };
        }

        private void txtVerify_Leave(object sender, EventArgs e)
        {
            panTxtVerify.BackColor = Color.SkyBlue;
        }

        private void txtVerify_Click(object sender, EventArgs e)
        {
            panTxtVerify.BackColor = Color.Yellow;
        }

        private void btnVerify_Click(object sender, EventArgs e)
        {
            if (txtVerify.Text == captcha && btnAgainSend.Visible == false)
            {
                MessageBox.Show("驗證成功","通知", MessageBoxButtons.OK,MessageBoxIcon.Information);
                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            else 
                MessageBox.Show("驗證碼錯誤!! 請再次嘗試", "通知", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        private void generateCaptcha()
        {
            captcha = "";
            for (int i = 0; i < 4; i++)
            {
                int asciiType = new Random().Next(0, 3); //0 數字, 1 小寫英文, 2 大寫英文 
                if (asciiType == 0)
                    captcha += Convert.ToChar(new Random().Next(48, 58));
                else if (asciiType == 1)
                    captcha += Convert.ToChar(new Random().Next(97, 123));
                else
                    captcha += Convert.ToChar(new Random().Next(65, 91));
            }
        }
        private void timer1_Tick(object sender, EventArgs e)
        {
            if (--RestedTime == 0)
            {
                RestedTime = 60;
                lblTimer.Text = "";
                CloseTimer();
            }
            else lblTimer.Text = $"{RestedTime} 秒";
        }
        private void btnAgainSend_Click(object sender, EventArgs e)
        {
            SendEmail();
        }
    }
}
