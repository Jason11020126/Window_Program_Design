﻿namespace Library_Reserved_System_AD
{
    partial class Reserved
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle4 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle5 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle3 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle6 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle11 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle12 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle7 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle8 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle9 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle10 = new DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Reserved));
            gridReservedInfo = new DataGridView();
            ReservedItem = new DataGridViewTextBoxColumn();
            ResevedPhone = new DataGridViewTextBoxColumn();
            Time1 = new DataGridViewTextBoxColumn();
            Time2 = new DataGridViewTextBoxColumn();
            Time3 = new DataGridViewTextBoxColumn();
            Time4 = new DataGridViewTextBoxColumn();
            Time5 = new DataGridViewTextBoxColumn();
            Time6 = new DataGridViewTextBoxColumn();
            Time7 = new DataGridViewTextBoxColumn();
            Time8 = new DataGridViewTextBoxColumn();
            lblSeat = new Label();
            comboSeat = new ComboBox();
            lblDate = new Label();
            date = new DateTimePicker();
            comboFloor = new ComboBox();
            lblDollars = new Label();
            lblTotalNum = new Label();
            lblTotalTitle = new Label();
            lblFloor = new Label();
            gridFood = new DataGridView();
            itemName = new DataGridViewTextBoxColumn();
            itemPrice = new DataGridViewTextBoxColumn();
            itemNum = new DataGridViewTextBoxColumn();
            subTotal = new DataGridViewTextBoxColumn();
            panComment = new Panel();
            txtComment = new TextBox();
            lblCommentTitle = new Label();
            ((System.ComponentModel.ISupportInitialize)gridReservedInfo).BeginInit();
            ((System.ComponentModel.ISupportInitialize)gridFood).BeginInit();
            panComment.SuspendLayout();
            SuspendLayout();
            // 
            // gridReservedInfo
            // 
            gridReservedInfo.AllowUserToAddRows = false;
            gridReservedInfo.AllowUserToDeleteRows = false;
            gridReservedInfo.AllowUserToResizeColumns = false;
            gridReservedInfo.AllowUserToResizeRows = false;
            gridReservedInfo.BackgroundColor = SystemColors.ControlLightLight;
            dataGridViewCellStyle1.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = SystemColors.ControlLightLight;
            dataGridViewCellStyle1.Font = new Font("標楷體", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            dataGridViewCellStyle1.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = SystemColors.ControlLightLight;
            dataGridViewCellStyle1.SelectionForeColor = SystemColors.ActiveCaptionText;
            dataGridViewCellStyle1.WrapMode = DataGridViewTriState.True;
            gridReservedInfo.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            gridReservedInfo.ColumnHeadersHeight = 25;
            gridReservedInfo.Columns.AddRange(new DataGridViewColumn[] { ReservedItem, ResevedPhone, Time1, Time2, Time3, Time4, Time5, Time6, Time7, Time8 });
            dataGridViewCellStyle4.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle4.BackColor = SystemColors.Window;
            dataGridViewCellStyle4.Font = new Font("標楷體", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            dataGridViewCellStyle4.ForeColor = SystemColors.ControlText;
            dataGridViewCellStyle4.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = DataGridViewTriState.False;
            gridReservedInfo.DefaultCellStyle = dataGridViewCellStyle4;
            gridReservedInfo.EnableHeadersVisualStyles = false;
            gridReservedInfo.GridColor = Color.Black;
            gridReservedInfo.Location = new Point(25, 99);
            gridReservedInfo.MultiSelect = false;
            gridReservedInfo.Name = "gridReservedInfo";
            gridReservedInfo.ReadOnly = true;
            dataGridViewCellStyle5.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = SystemColors.Control;
            dataGridViewCellStyle5.Font = new Font("標楷體", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            dataGridViewCellStyle5.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle5.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = DataGridViewTriState.True;
            gridReservedInfo.RowHeadersDefaultCellStyle = dataGridViewCellStyle5;
            gridReservedInfo.RowHeadersVisible = false;
            gridReservedInfo.ScrollBars = ScrollBars.None;
            gridReservedInfo.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            gridReservedInfo.Size = new Size(1309, 226);
            gridReservedInfo.TabIndex = 90;
            gridReservedInfo.SelectionChanged += gridReservedInfo_SelectionChanged;
            // 
            // ReservedItem
            // 
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleCenter;
            ReservedItem.DefaultCellStyle = dataGridViewCellStyle2;
            ReservedItem.HeaderText = "預約者";
            ReservedItem.Name = "ReservedItem";
            ReservedItem.ReadOnly = true;
            ReservedItem.SortMode = DataGridViewColumnSortMode.NotSortable;
            ReservedItem.Width = 185;
            // 
            // ResevedPhone
            // 
            dataGridViewCellStyle3.Alignment = DataGridViewContentAlignment.MiddleCenter;
            ResevedPhone.DefaultCellStyle = dataGridViewCellStyle3;
            ResevedPhone.HeaderText = "電話";
            ResevedPhone.Name = "ResevedPhone";
            ResevedPhone.ReadOnly = true;
            ResevedPhone.SortMode = DataGridViewColumnSortMode.NotSortable;
            ResevedPhone.Width = 165;
            // 
            // Time1
            // 
            Time1.HeaderText = "08:00-09:00";
            Time1.Name = "Time1";
            Time1.ReadOnly = true;
            Time1.SortMode = DataGridViewColumnSortMode.NotSortable;
            Time1.Width = 120;
            // 
            // Time2
            // 
            Time2.HeaderText = "09:00-10:00";
            Time2.Name = "Time2";
            Time2.ReadOnly = true;
            Time2.SortMode = DataGridViewColumnSortMode.NotSortable;
            Time2.Width = 120;
            // 
            // Time3
            // 
            Time3.HeaderText = "10:00-11:00";
            Time3.Name = "Time3";
            Time3.ReadOnly = true;
            Time3.SortMode = DataGridViewColumnSortMode.NotSortable;
            Time3.Width = 120;
            // 
            // Time4
            // 
            Time4.HeaderText = "11:00-12:00";
            Time4.Name = "Time4";
            Time4.ReadOnly = true;
            Time4.SortMode = DataGridViewColumnSortMode.NotSortable;
            Time4.Width = 120;
            // 
            // Time5
            // 
            Time5.HeaderText = "12:00-13:00";
            Time5.Name = "Time5";
            Time5.ReadOnly = true;
            Time5.SortMode = DataGridViewColumnSortMode.NotSortable;
            Time5.Width = 120;
            // 
            // Time6
            // 
            Time6.HeaderText = "13:00-14:00";
            Time6.Name = "Time6";
            Time6.ReadOnly = true;
            Time6.SortMode = DataGridViewColumnSortMode.NotSortable;
            Time6.Width = 120;
            // 
            // Time7
            // 
            Time7.HeaderText = "14:00-15:00";
            Time7.Name = "Time7";
            Time7.ReadOnly = true;
            Time7.SortMode = DataGridViewColumnSortMode.NotSortable;
            Time7.Width = 120;
            // 
            // Time8
            // 
            Time8.HeaderText = "15:00-16:00";
            Time8.Name = "Time8";
            Time8.ReadOnly = true;
            Time8.SortMode = DataGridViewColumnSortMode.NotSortable;
            Time8.Width = 120;
            // 
            // lblSeat
            // 
            lblSeat.AutoSize = true;
            lblSeat.Font = new Font("標楷體", 14.25F);
            lblSeat.Location = new Point(546, 9);
            lblSeat.Name = "lblSeat";
            lblSeat.Size = new Size(49, 19);
            lblSeat.TabIndex = 89;
            lblSeat.Text = "座位";
            // 
            // comboSeat
            // 
            comboSeat.BackColor = Color.White;
            comboSeat.DropDownHeight = 100;
            comboSeat.DropDownStyle = ComboBoxStyle.DropDownList;
            comboSeat.DropDownWidth = 5;
            comboSeat.FlatStyle = FlatStyle.Popup;
            comboSeat.Font = new Font("標楷體", 14.25F);
            comboSeat.FormattingEnabled = true;
            comboSeat.IntegralHeight = false;
            comboSeat.Location = new Point(546, 37);
            comboSeat.MaxDropDownItems = 5;
            comboSeat.MaxLength = 5;
            comboSeat.Name = "comboSeat";
            comboSeat.Size = new Size(254, 27);
            comboSeat.TabIndex = 88;
            // 
            // lblDate
            // 
            lblDate.AutoSize = true;
            lblDate.Font = new Font("標楷體", 14.25F);
            lblDate.Location = new Point(822, 9);
            lblDate.Name = "lblDate";
            lblDate.Size = new Size(49, 19);
            lblDate.TabIndex = 87;
            lblDate.Text = "日期";
            // 
            // date
            // 
            date.Font = new Font("標楷體", 14.25F);
            date.Location = new Point(822, 37);
            date.MinDate = new DateTime(2025, 5, 29, 21, 37, 31, 814);
            date.Name = "date";
            date.Size = new Size(254, 30);
            date.TabIndex = 86;
            date.Value = new DateTime(2025, 5, 29, 21, 37, 31, 814);
            // 
            // comboFloor
            // 
            comboFloor.BackColor = Color.White;
            comboFloor.DropDownStyle = ComboBoxStyle.DropDownList;
            comboFloor.FlatStyle = FlatStyle.Flat;
            comboFloor.Font = new Font("標楷體", 14.25F);
            comboFloor.FormattingEnabled = true;
            comboFloor.Items.AddRange(new object[] { "一樓", "二樓" });
            comboFloor.Location = new Point(270, 37);
            comboFloor.Name = "comboFloor";
            comboFloor.Size = new Size(254, 27);
            comboFloor.TabIndex = 85;
            comboFloor.TabStop = false;
            // 
            // lblDollars
            // 
            lblDollars.AutoSize = true;
            lblDollars.Font = new Font("標楷體", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblDollars.Location = new Point(781, 690);
            lblDollars.Name = "lblDollars";
            lblDollars.Size = new Size(29, 19);
            lblDollars.TabIndex = 83;
            lblDollars.Text = "元";
            // 
            // lblTotalNum
            // 
            lblTotalNum.Font = new Font("標楷體", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblTotalNum.Location = new Point(584, 688);
            lblTotalNum.Name = "lblTotalNum";
            lblTotalNum.Size = new Size(190, 23);
            lblTotalNum.TabIndex = 82;
            lblTotalNum.Text = "0";
            lblTotalNum.TextAlign = ContentAlignment.MiddleRight;
            // 
            // lblTotalTitle
            // 
            lblTotalTitle.Font = new Font("標楷體", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblTotalTitle.ForeColor = Color.Black;
            lblTotalTitle.Location = new Point(503, 688);
            lblTotalTitle.Name = "lblTotalTitle";
            lblTotalTitle.Size = new Size(212, 21);
            lblTotalTitle.TabIndex = 81;
            lblTotalTitle.Text = "總計:";
            // 
            // lblFloor
            // 
            lblFloor.AutoSize = true;
            lblFloor.Font = new Font("標楷體", 14.25F);
            lblFloor.Location = new Point(270, 9);
            lblFloor.Name = "lblFloor";
            lblFloor.Size = new Size(49, 19);
            lblFloor.TabIndex = 84;
            lblFloor.Text = "樓層";
            // 
            // gridFood
            // 
            gridFood.AllowUserToAddRows = false;
            gridFood.AllowUserToDeleteRows = false;
            gridFood.AllowUserToResizeColumns = false;
            gridFood.AllowUserToResizeRows = false;
            gridFood.BackgroundColor = SystemColors.ControlLightLight;
            dataGridViewCellStyle6.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle6.BackColor = SystemColors.ControlLightLight;
            dataGridViewCellStyle6.Font = new Font("標楷體", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            dataGridViewCellStyle6.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle6.SelectionBackColor = SystemColors.ControlLightLight;
            dataGridViewCellStyle6.SelectionForeColor = SystemColors.ControlLightLight;
            dataGridViewCellStyle6.WrapMode = DataGridViewTriState.False;
            gridFood.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle6;
            gridFood.ColumnHeadersHeight = 25;
            gridFood.Columns.AddRange(new DataGridViewColumn[] { itemName, itemPrice, itemNum, subTotal });
            dataGridViewCellStyle11.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle11.BackColor = SystemColors.ControlLightLight;
            dataGridViewCellStyle11.Font = new Font("標楷體", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            dataGridViewCellStyle11.ForeColor = Color.Black;
            dataGridViewCellStyle11.SelectionBackColor = SystemColors.ControlLightLight;
            dataGridViewCellStyle11.SelectionForeColor = Color.Black;
            dataGridViewCellStyle11.WrapMode = DataGridViewTriState.False;
            gridFood.DefaultCellStyle = dataGridViewCellStyle11;
            gridFood.EnableHeadersVisualStyles = false;
            gridFood.GridColor = Color.Black;
            gridFood.Location = new Point(25, 343);
            gridFood.MultiSelect = false;
            gridFood.Name = "gridFood";
            gridFood.ReadOnly = true;
            dataGridViewCellStyle12.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle12.BackColor = SystemColors.ControlLightLight;
            dataGridViewCellStyle12.Font = new Font("標楷體", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            dataGridViewCellStyle12.ForeColor = SystemColors.ControlLightLight;
            dataGridViewCellStyle12.SelectionBackColor = SystemColors.HighlightText;
            dataGridViewCellStyle12.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle12.WrapMode = DataGridViewTriState.True;
            gridFood.RowHeadersDefaultCellStyle = dataGridViewCellStyle12;
            gridFood.RowHeadersVisible = false;
            gridFood.ScrollBars = ScrollBars.Vertical;
            gridFood.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            gridFood.Size = new Size(738, 316);
            gridFood.TabIndex = 80;
            // 
            // itemName
            // 
            dataGridViewCellStyle7.Alignment = DataGridViewContentAlignment.MiddleCenter;
            itemName.DefaultCellStyle = dataGridViewCellStyle7;
            itemName.FillWeight = 300F;
            itemName.HeaderText = "商品名稱";
            itemName.Name = "itemName";
            itemName.ReadOnly = true;
            itemName.Resizable = DataGridViewTriState.False;
            itemName.Width = 350;
            // 
            // itemPrice
            // 
            dataGridViewCellStyle8.Alignment = DataGridViewContentAlignment.MiddleCenter;
            itemPrice.DefaultCellStyle = dataGridViewCellStyle8;
            itemPrice.HeaderText = "單價";
            itemPrice.Name = "itemPrice";
            itemPrice.ReadOnly = true;
            itemPrice.Resizable = DataGridViewTriState.False;
            itemPrice.SortMode = DataGridViewColumnSortMode.NotSortable;
            itemPrice.Width = 120;
            // 
            // itemNum
            // 
            dataGridViewCellStyle9.Alignment = DataGridViewContentAlignment.MiddleCenter;
            itemNum.DefaultCellStyle = dataGridViewCellStyle9;
            itemNum.HeaderText = "數量";
            itemNum.Name = "itemNum";
            itemNum.ReadOnly = true;
            itemNum.Resizable = DataGridViewTriState.False;
            itemNum.SortMode = DataGridViewColumnSortMode.NotSortable;
            itemNum.Width = 120;
            // 
            // subTotal
            // 
            dataGridViewCellStyle10.Alignment = DataGridViewContentAlignment.MiddleCenter;
            subTotal.DefaultCellStyle = dataGridViewCellStyle10;
            subTotal.HeaderText = "小計";
            subTotal.Name = "subTotal";
            subTotal.ReadOnly = true;
            subTotal.Resizable = DataGridViewTriState.False;
            subTotal.SortMode = DataGridViewColumnSortMode.NotSortable;
            subTotal.Width = 150;
            // 
            // panComment
            // 
            panComment.BackColor = Color.Gainsboro;
            panComment.Controls.Add(txtComment);
            panComment.Controls.Add(lblCommentTitle);
            panComment.Location = new Point(781, 343);
            panComment.Name = "panComment";
            panComment.Size = new Size(553, 316);
            panComment.TabIndex = 91;
            // 
            // txtComment
            // 
            txtComment.BackColor = SystemColors.ButtonHighlight;
            txtComment.Font = new Font("標楷體", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtComment.Location = new Point(12, 43);
            txtComment.Multiline = true;
            txtComment.Name = "txtComment";
            txtComment.PlaceholderText = "無留言或建議";
            txtComment.Size = new Size(528, 260);
            txtComment.TabIndex = 39;
            // 
            // lblCommentTitle
            // 
            lblCommentTitle.BackColor = Color.Gainsboro;
            lblCommentTitle.Font = new Font("標楷體", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblCommentTitle.Location = new Point(12, 10);
            lblCommentTitle.Name = "lblCommentTitle";
            lblCommentTitle.Size = new Size(528, 30);
            lblCommentTitle.TabIndex = 37;
            lblCommentTitle.Text = "備註或建議";
            lblCommentTitle.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // Reserved
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.AntiqueWhite;
            ClientSize = new Size(1355, 733);
            Controls.Add(panComment);
            Controls.Add(gridReservedInfo);
            Controls.Add(lblSeat);
            Controls.Add(comboSeat);
            Controls.Add(lblDate);
            Controls.Add(date);
            Controls.Add(comboFloor);
            Controls.Add(lblDollars);
            Controls.Add(lblTotalNum);
            Controls.Add(lblTotalTitle);
            Controls.Add(lblFloor);
            Controls.Add(gridFood);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "Reserved";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "小歇一刻K書中心- 預約檢視";
            Click += Reserved_Click;
            ((System.ComponentModel.ISupportInitialize)gridReservedInfo).EndInit();
            ((System.ComponentModel.ISupportInitialize)gridFood).EndInit();
            panComment.ResumeLayout(false);
            panComment.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private DataGridView gridReservedInfo;
        private Label lblSeat;
        private ComboBox comboSeat;
        private Label lblDate;
        private DateTimePicker date;
        private ComboBox comboFloor;
        private Label lblDollars;
        private Label lblTotalNum;
        private Label lblTotalTitle;
        private Label lblFloor;
        private DataGridView gridFood;
        private Panel panComment;
        private TextBox txtComment;
        private Label lblCommentTitle;
        private DataGridViewTextBoxColumn ReservedItem;
        private DataGridViewTextBoxColumn ResevedPhone;
        private DataGridViewTextBoxColumn Time1;
        private DataGridViewTextBoxColumn Time2;
        private DataGridViewTextBoxColumn Time3;
        private DataGridViewTextBoxColumn Time4;
        private DataGridViewTextBoxColumn Time5;
        private DataGridViewTextBoxColumn Time6;
        private DataGridViewTextBoxColumn Time7;
        private DataGridViewTextBoxColumn Time8;
        private DataGridViewTextBoxColumn itemName;
        private DataGridViewTextBoxColumn itemPrice;
        private DataGridViewTextBoxColumn itemNum;
        private DataGridViewTextBoxColumn subTotal;
    }
}
